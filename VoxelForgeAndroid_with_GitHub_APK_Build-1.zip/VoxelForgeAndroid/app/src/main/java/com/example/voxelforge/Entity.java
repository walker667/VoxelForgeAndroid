package com.example.voxelforge;

public class Entity {
    public static final int PASSIVE = 0;
    public static final int HOSTILE = 1;
    public float x, y, z;
    public float vx, vz;
    public int type;
    public float health = 6f;
    public float damageCooldown = 0f;

    public Entity(int type, float x, float y, float z) {
        this.type = type;
        this.x = x;
        this.y = y;
        this.z = z;
    }
}
