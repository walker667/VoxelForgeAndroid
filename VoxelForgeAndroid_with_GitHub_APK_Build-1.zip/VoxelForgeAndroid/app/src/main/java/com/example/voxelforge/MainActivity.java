package com.example.voxelforge;

import android.app.Activity;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private FrameLayout root;
    private GameSettings settings;
    private VoxelSurfaceView surfaceView;
    private HudView hudView;
    private VoxelRenderer renderer;
    private MediaPlayer ambientPlayer;
    private SoundPool menuPool;
    private int clickSound;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        settings = new GameSettings();
        settings.load(this);
        setupSound();
        showMainMenu();
    }

    private void setupSound() {
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        menuPool = new SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build();
        clickSound = menuPool.load(this, R.raw.click, 1);
    }

    private void click() {
        if (menuPool != null) menuPool.play(clickSound, settings.volume, settings.volume, 1, 0, 1f);
    }

    private TextView title(String text, int sp) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(sp);
        tv.setGravity(Gravity.CENTER);
        tv.setShadowLayer(8, 2, 2, Color.BLACK);
        return tv;
    }

    private Button menuButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(18);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.rgb(35, 105, 65));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(240), dp(56));
        lp.setMargins(0, dp(8), 0, dp(8));
        b.setLayoutParams(lp);
        return b;
    }

    public void showMainMenu() {
        stopGame();
        hideSystemUI();
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(19, 34, 51));

        LinearLayout menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setGravity(Gravity.CENTER);
        menu.setPadding(dp(16), dp(16), dp(16), dp(16));
        root.addView(menu, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        TextView name = title("Voxel Forge", 42);
        TextView sub = title("Original mobile voxel sandbox", 16);
        menu.addView(name, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(70)));
        menu.addView(sub, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(34)));

        Button play = menuButton("Play World");
        Button settingsButton = menuButton("Settings");
        Button quit = menuButton("Quit");
        menu.addView(play);
        menu.addView(settingsButton);
        menu.addView(quit);

        play.setOnClickListener(v -> { click(); showLoadingThenGame(); });
        settingsButton.setOnClickListener(v -> { click(); showSettings(); });
        quit.setOnClickListener(v -> { click(); finish(); });
        setContentView(root);
    }

    private void showLoadingThenGame() {
        FrameLayout loading = new FrameLayout(this);
        loading.setBackgroundColor(Color.rgb(15, 20, 28));
        TextView text = title("Generating world...", 24);
        loading.addView(text, centeredParams());
        setContentView(loading);
        loading.postDelayed(this::startGame, 250);
    }

    private void startGame() {
        hideSystemUI();
        InputState input = new InputState();
        renderer = new VoxelRenderer(this, input, settings, () -> runOnUiThread(this::showPauseMenu));
        surfaceView = new VoxelSurfaceView(this, renderer);
        hudView = new HudView(this, input, renderer, settings);

        root = new FrameLayout(this);
        root.addView(surfaceView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(hudView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        startAmbient();
    }

    private void startAmbient() {
        try {
            ambientPlayer = MediaPlayer.create(this, R.raw.ambient);
            if (ambientPlayer != null) {
                ambientPlayer.setLooping(true);
                ambientPlayer.setVolume(settings.volume * 0.35f, settings.volume * 0.35f);
                ambientPlayer.start();
            }
        } catch (Exception ignored) {}
    }

    private void stopAmbient() {
        if (ambientPlayer != null) {
            ambientPlayer.stop();
            ambientPlayer.release();
            ambientPlayer = null;
        }
    }

    private FrameLayout.LayoutParams centeredParams() {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.CENTER;
        return lp;
    }

    private void showPauseMenu() {
        if (root == null || surfaceView == null) return;
        surfaceView.onPause();
        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(Color.argb(190, 0, 0, 0));
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        overlay.addView(box, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        box.addView(title("Paused", 32), new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(60)));
        Button resume = menuButton("Resume");
        Button save = menuButton("Save World");
        Button settingsButton = menuButton("Settings");
        Button exit = menuButton("Exit to Menu");
        box.addView(resume);
        box.addView(save);
        box.addView(settingsButton);
        box.addView(exit);
        root.addView(overlay);
        resume.setOnClickListener(v -> { click(); root.removeView(overlay); surfaceView.onResume(); hideSystemUI(); });
        save.setOnClickListener(v -> { click(); if (renderer != null) renderer.saveGame(); Toast.makeText(this, "World saved", Toast.LENGTH_SHORT).show(); });
        settingsButton.setOnClickListener(v -> { click(); showSettings(); });
        exit.setOnClickListener(v -> { click(); if (renderer != null) renderer.saveGame(); showMainMenu(); });
    }

    private void showSettings() {
        stopAmbient();
        hideSystemUI();
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(18, 30, 42));
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(24), dp(18), dp(24), dp(18));
        root.addView(box, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        box.addView(title("Settings", 32), new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54)));
        addSlider(box, "Look sensitivity", 5, 40, (int)(settings.sensitivity * 100), v -> settings.sensitivity = v / 100f);
        addSlider(box, "Render distance", 2, 5, settings.renderDistance, v -> settings.renderDistance = v);
        addSlider(box, "Volume", 0, 100, (int)(settings.volume * 100), v -> settings.volume = v / 100f);
        addSlider(box, "Graphics quality", 0, 2, settings.quality, v -> settings.quality = v);
        Button back = menuButton("Save and Back");
        box.addView(back);
        back.setOnClickListener(v -> { click(); settings.save(this); showMainMenu(); });
        setContentView(root);
    }

    private interface SliderChange { void set(int value); }

    private void addSlider(LinearLayout box, String label, int min, int max, int value, SliderChange change) {
        TextView tv = title(label + ": " + value, 15);
        SeekBar seek = new SeekBar(this);
        seek.setMax(max - min);
        seek.setProgress(value - min);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                int val = progress + min;
                tv.setText(label + ": " + val);
                change.set(val);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        box.addView(tv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(28)));
        box.addView(seek, new LinearLayout.LayoutParams(dp(320), dp(46)));
    }

    private void stopGame() {
        stopAmbient();
        if (surfaceView != null) surfaceView.onPause();
        if (renderer != null) renderer.saveGame();
        surfaceView = null;
        renderer = null;
        hudView = null;
    }

    @Override protected void onPause() {
        super.onPause();
        if (surfaceView != null) surfaceView.onPause();
        if (renderer != null) renderer.saveGame();
        stopAmbient();
    }

    @Override protected void onResume() {
        super.onResume();
        hideSystemUI();
        if (surfaceView != null) surfaceView.onResume();
        if (surfaceView != null && ambientPlayer == null) startAmbient();
    }

    @Override protected void onDestroy() {
        stopGame();
        if (menuPool != null) menuPool.release();
        super.onDestroy();
    }

    private void hideSystemUI() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    public int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
