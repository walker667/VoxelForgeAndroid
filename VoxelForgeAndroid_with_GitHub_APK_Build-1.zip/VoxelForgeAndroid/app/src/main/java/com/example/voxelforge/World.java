package com.example.voxelforge;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class World {
    public static final int CHUNK_SIZE = 16;
    public static final int HEIGHT = 72;
    public static final int WATER_LEVEL = 22;
    public final int seed;
    private final Map<Long, Chunk> chunks = new HashMap<>();
    private final Map<Long, Byte> edits = new HashMap<>();
    private int lastCenterCx = Integer.MIN_VALUE;
    private int lastCenterCz = Integer.MIN_VALUE;
    private int lastRenderDistance = -1;

    public World(int seed) {
        this.seed = seed;
    }

    public void updateChunks(float px, float pz, int renderDistance) {
        int ccx = floorDiv(floor(px), CHUNK_SIZE);
        int ccz = floorDiv(floor(pz), CHUNK_SIZE);
        if (ccx == lastCenterCx && ccz == lastCenterCz && renderDistance == lastRenderDistance) return;
        lastCenterCx = ccx;
        lastCenterCz = ccz;
        lastRenderDistance = renderDistance;
        for (int dz = -renderDistance; dz <= renderDistance; dz++) {
            for (int dx = -renderDistance; dx <= renderDistance; dx++) {
                long key = chunkKey(ccx + dx, ccz + dz);
                if (!chunks.containsKey(key)) chunks.put(key, new Chunk(this, ccx + dx, ccz + dz));
            }
        }
        Iterator<Map.Entry<Long, Chunk>> it = chunks.entrySet().iterator();
        while (it.hasNext()) {
            Chunk c = it.next().getValue();
            int dx = c.cx - ccx, dz = c.cz - ccz;
            if (Math.abs(dx) > renderDistance + 1 || Math.abs(dz) > renderDistance + 1) {
                c.releaseGl();
                it.remove();
            }
        }
    }

    public List<Chunk> visibleChunks() {
        return new ArrayList<>(chunks.values());
    }

    public byte getBlock(int wx, int y, int wz) {
        if (y < 0 || y >= HEIGHT) return Block.AIR;
        long editKey = editKey(wx, y, wz);
        Byte e = edits.get(editKey);
        if (e != null) return e;
        int cx = floorDiv(wx, CHUNK_SIZE);
        int cz = floorDiv(wz, CHUNK_SIZE);
        Chunk c = chunks.get(chunkKey(cx, cz));
        if (c != null) return c.getLocal(mod(wx, CHUNK_SIZE), y, mod(wz, CHUNK_SIZE));
        return generatedBlock(wx, y, wz);
    }

    public void setBlock(int wx, int y, int wz, byte block) {
        if (y < 0 || y >= HEIGHT) return;
        edits.put(editKey(wx, y, wz), block);
        int cx = floorDiv(wx, CHUNK_SIZE);
        int cz = floorDiv(wz, CHUNK_SIZE);
        Chunk c = chunks.get(chunkKey(cx, cz));
        if (c != null) {
            c.setLocal(mod(wx, CHUNK_SIZE), y, mod(wz, CHUNK_SIZE), block);
            c.markDirty();
        }
        markNeighborDirty(wx, y, wz);
    }

    private void markNeighborDirty(int wx, int y, int wz) {
        int[][] d = {{1,0},{-1,0},{0,1},{0,-1}};
        for (int[] a : d) {
            int cx = floorDiv(wx + a[0], CHUNK_SIZE);
            int cz = floorDiv(wz + a[1], CHUNK_SIZE);
            Chunk n = chunks.get(chunkKey(cx, cz));
            if (n != null) n.markDirty();
        }
    }

    public int heightAt(int wx, int wz) {
        float continental = Noise.value2D(seed + 77, wx, wz, 0.004f);
        float n = Noise.fractal2D(seed, wx, wz);
        float hills = Noise.value2D(seed + 113, wx, wz, 0.012f);
        int h = (int)(WATER_LEVEL + 6 + n * 12f + Math.max(0, hills) * 10f + continental * 6f);
        if (h < 10) h = 10;
        if (h > HEIGHT - 8) h = HEIGHT - 8;
        return h;
    }

    public byte generatedBlock(int wx, int y, int wz) {
        int h = heightAt(wx, wz);
        if (y > h) {
            if (y <= WATER_LEVEL) return Block.WATER;
            return Block.AIR;
        }
        float cave = Noise.value3D(seed + 888, wx, y, wz, 0.055f) + Noise.value3D(seed + 42, wx, y, wz, 0.03f) * 0.4f;
        if (y > 4 && y < h - 5 && cave > 0.74f) return Block.AIR;
        if (h <= WATER_LEVEL + 2) {
            if (y >= h - 2) return Block.SAND;
        }
        if (y == h) return Block.GRASS;
        if (y > h - 4) return Block.DIRT;
        float ore = Noise.value3D(seed + 321, wx, y, wz, 0.09f);
        if (y < 38 && ore > 0.78f) return Block.ORE;
        return Block.STONE;
    }

    public boolean shouldTreeGrow(int wx, int wz) {
        int h = heightAt(wx, wz);
        if (h <= WATER_LEVEL + 2) return false;
        float forest = Noise.value2D(seed + 555, wx, wz, 0.015f);
        if (forest < -0.1f) return false;
        return Noise.hash01(seed + 901, floorDiv(wx, 4), floorDiv(wz, 4), 0) > 0.88f && mod(wx, 4) == 1 && mod(wz, 4) == 1;
    }

    public byte treeBlock(int wx, int y, int wz) {
        for (int ox = -2; ox <= 2; ox++) {
            for (int oz = -2; oz <= 2; oz++) {
                int tx = wx + ox;
                int tz = wz + oz;
                if (!shouldTreeGrow(tx, tz)) continue;
                int base = heightAt(tx, tz) + 1;
                int dx = Math.abs(wx - tx), dz = Math.abs(wz - tz);
                if (wx == tx && wz == tz && y >= base && y <= base + 4) return Block.WOOD;
                int leafY = y - (base + 3);
                if (leafY >= -1 && leafY <= 3 && dx <= 2 && dz <= 2 && dx + dz + Math.abs(leafY) < 5) return Block.LEAVES;
            }
        }
        return Block.AIR;
    }

    public Map<Long, Byte> getEdits() { return edits; }

    public void loadEdits(String data) {
        edits.clear();
        if (data == null || data.isEmpty()) return;
        String[] entries = data.split(";");
        for (String s : entries) {
            if (s.trim().isEmpty()) continue;
            String[] p = s.split(",");
            if (p.length != 4) continue;
            try {
                int x = Integer.parseInt(p[0]);
                int y = Integer.parseInt(p[1]);
                int z = Integer.parseInt(p[2]);
                byte b = (byte)Integer.parseInt(p[3]);
                edits.put(editKey(x, y, z), b);
            } catch (Exception ignored) {}
        }
    }

    public String saveEdits() {
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (Map.Entry<Long, Byte> e : edits.entrySet()) {
            int[] xyz = unpackEdit(e.getKey());
            sb.append(xyz[0]).append(',').append(xyz[1]).append(',').append(xyz[2]).append(',').append(e.getValue()).append(';');
            count++;
            if (count > 8000) break; // keep SharedPreferences from becoming huge
        }
        return sb.toString();
    }

    static long chunkKey(int cx, int cz) {
        return (((long)cx) << 32) ^ (cz & 0xffffffffL);
    }

    static long editKey(int x, int y, int z) {
        long xx = (x + 1048576L) & 0x1FFFFFL;
        long zz = (z + 1048576L) & 0x1FFFFFL;
        long yy = y & 0x3FFL;
        return (xx << 31) | (zz << 10) | yy;
    }

    static int[] unpackEdit(long key) {
        int y = (int)(key & 0x3FFL);
        int z = (int)((key >> 10) & 0x1FFFFFL) - 1048576;
        int x = (int)((key >> 31) & 0x1FFFFFL) - 1048576;
        return new int[]{x, y, z};
    }

    static int floor(float v) { return v >= 0 ? (int)v : (int)v - 1; }
    static int floorDiv(int a, int b) { int r = a / b; if ((a ^ b) < 0 && r * b != a) r--; return r; }
    static int mod(int a, int b) { int m = a % b; return m < 0 ? m + b : m; }
}
