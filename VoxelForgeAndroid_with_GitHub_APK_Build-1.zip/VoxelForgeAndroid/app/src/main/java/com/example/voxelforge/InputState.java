package com.example.voxelforge;

public class InputState {
    public volatile float moveX = 0f;
    public volatile float moveY = 0f;
    public volatile boolean jumpHeld = false;
    public volatile boolean breakingHeld = false;
    public volatile boolean placingHeld = false;
    public volatile boolean craftPressed = false;
    public volatile boolean savePressed = false;
    public volatile boolean pausePressed = false;
    public volatile int selectedSlot = 0;

    private float lookDx = 0f;
    private float lookDy = 0f;

    public synchronized void addLook(float dx, float dy) {
        lookDx += dx;
        lookDy += dy;
    }

    public synchronized float consumeLookDx() {
        float v = lookDx;
        lookDx = 0f;
        return v;
    }

    public synchronized float consumeLookDy() {
        float v = lookDy;
        lookDy = 0f;
        return v;
    }

    public synchronized boolean consumeCraftPressed() {
        boolean v = craftPressed;
        craftPressed = false;
        return v;
    }

    public synchronized boolean consumeSavePressed() {
        boolean v = savePressed;
        savePressed = false;
        return v;
    }

    public synchronized boolean consumePausePressed() {
        boolean v = pausePressed;
        pausePressed = false;
        return v;
    }
}
