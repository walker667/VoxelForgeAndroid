package com.example.voxelforge;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {
    GameView game;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        hideBars();
        game = new GameView(this);
        setContentView(game);
    }

    @Override protected void onPause() {
        if (game != null) game.save();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        hideBars();
        if (game != null) game.resume();
    }

    void hideBars() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    static class GameView extends View {
        static final int MENU = 0, GAME = 1, SETTINGS = 2, PAUSE = 3;
        static final byte AIR=0, GRASS=1, DIRT=2, STONE=3, SAND=4, WATER=5, WOOD=6, LEAVES=7, ORE=8, TORCH=9;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        final SharedPreferences prefs;
        final Map<Long, Byte> edits = new HashMap<>();
        final List<Mob> mobs = new ArrayList<>();
        ToneGenerator tone;
        int screen = MENU;
        long lastNs = 0;
        int seed = 1337;
        float px = 0.5f, pz = 0.5f, yaw = 0f, jump = 0f, vy = 0f;
        float health = 20f, hunger = 20f, day = 0.28f;
        float sensitivity = 0.0065f;
        int renderQuality = 2;
        int selected = 0;
        byte[] hotbar = {GRASS, DIRT, STONE, SAND, WOOD, LEAVES, ORE, TORCH};
        int[] inv = {999,999,999,999,999,999,999,999};
        boolean moving=false, jumpHeld=false, breakHeld=false;
        float moveX=0, moveY=0, breakTimer=0, saveTimer=0, mobTimer=0, hitFlash=0;
        int leftPointer=-1, rightPointer=-1;
        float joyCx, joyCy, joyX, joyY, lastLookX;
        RectF playBtn = new RectF(), settingsBtn = new RectF(), quitBtn = new RectF(), backBtn = new RectF();
        RectF pauseBtn = new RectF(), breakBtn = new RectF(), placeBtn = new RectF(), jumpBtn = new RectF(), craftBtn = new RectF();

        GameView(Context c) {
            super(c);
            setFocusable(true);
            text.setColor(Color.WHITE);
            text.setTextAlign(Paint.Align.CENTER);
            prefs = c.getSharedPreferences("safe_world", Context.MODE_PRIVATE);
            try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 50); } catch (Throwable ignored) {}
            load();
        }

        void resume() { lastNs = System.nanoTime(); invalidate(); }

        void load() {
            seed = prefs.getInt("seed", (int)(System.currentTimeMillis() & 0x7fffffff));
            px = prefs.getFloat("px", 0.5f);
            pz = prefs.getFloat("pz", 0.5f);
            yaw = prefs.getFloat("yaw", 0f);
            health = prefs.getFloat("health", 20f);
            hunger = prefs.getFloat("hunger", 20f);
            day = prefs.getFloat("day", 0.28f);
            selected = prefs.getInt("selected", 0);
            sensitivity = prefs.getFloat("sensitivity", 0.0065f);
            renderQuality = prefs.getInt("quality", 2);
            edits.clear();
            String s = prefs.getString("edits", "");
            if (s != null && s.length() > 0) {
                String[] e = s.split(";");
                for (String item : e) {
                    String[] a = item.split(",");
                    if (a.length == 3) {
                        try { edits.put(key(Integer.parseInt(a[0]), Integer.parseInt(a[1])), (byte)Integer.parseInt(a[2])); } catch (Exception ignored) {}
                    }
                }
            }
        }

        void save() {
            StringBuilder sb = new StringBuilder();
            int count = 0;
            for (Map.Entry<Long, Byte> e : edits.entrySet()) {
                int x = unpackX(e.getKey()), z = unpackZ(e.getKey());
                sb.append(x).append(',').append(z).append(',').append(e.getValue()).append(';');
                if (++count > 3000) break;
            }
            prefs.edit().putInt("seed", seed).putFloat("px", px).putFloat("pz", pz).putFloat("yaw", yaw)
                    .putFloat("health", health).putFloat("hunger", hunger).putFloat("day", day)
                    .putInt("selected", selected).putFloat("sensitivity", sensitivity).putInt("quality", renderQuality)
                    .putString("edits", sb.toString()).apply();
        }

        @Override protected void onDraw(Canvas c) {
            long now = System.nanoTime();
            float dt = lastNs == 0 ? 0.016f : Math.min(0.05f, (now - lastNs) / 1000000000f);
            lastNs = now;
            if (screen == GAME) update(dt);
            draw(c);
            invalidate();
        }

        void update(float dt) {
            day += dt / 360f; if (day > 1f) day -= 1f;
            if (hitFlash > 0) hitFlash -= dt;
            float speed = hunger < 3 ? 1.8f : 3.0f;
            float sy = (float)Math.sin(yaw), cy = (float)Math.cos(yaw);
            float dx = (cy * moveX + sy * moveY) * speed * dt;
            float dz = (-sy * moveX + cy * moveY) * speed * dt;
            tryMove(dx, dz);
            if (Math.abs(moveX) + Math.abs(moveY) > 0.1f) hunger = Math.max(0, hunger - dt * 0.04f);
            if (jumpHeld && jump <= 0.01f && hunger > 0) { vy = 3.2f; jumpHeld = false; beep(3); }
            vy -= 8f * dt;
            jump += vy * dt;
            if (jump < 0) { jump = 0; vy = 0; }
            if (breakHeld) {
                breakTimer += dt;
                Ray r = castRay(7f);
                if (r.hit && breakTimer > 0.32f) {
                    setBlock(r.bx, r.bz, AIR);
                    hunger = Math.max(0, hunger - 0.02f);
                    beep(1);
                    breakTimer = 0f;
                }
            } else breakTimer = 0f;
            updateMobs(dt);
            saveTimer += dt; if (saveTimer > 8f) { save(); saveTimer = 0; }
        }

        void updateMobs(float dt) {
            boolean night = light() < 0.35f;
            mobTimer -= dt;
            if (mobTimer <= 0) {
                int hostiles=0, animals=0;
                for (Mob m : mobs) if (m.hostile) hostiles++; else animals++;
                if (night && hostiles < 5) spawnMob(true);
                if (!night && animals < 6) spawnMob(false);
                mobTimer = night ? 4f : 7f;
            }
            Iterator<Mob> it = mobs.iterator();
            while (it.hasNext()) {
                Mob m = it.next();
                float dx = px - m.x, dz = pz - m.z;
                float dist = (float)Math.sqrt(dx*dx + dz*dz);
                if (dist > 40) { it.remove(); continue; }
                if (m.hostile && night) {
                    dx /= Math.max(0.001f, dist); dz /= Math.max(0.001f, dist);
                    m.x += dx * 1.3f * dt; m.z += dz * 1.3f * dt;
                    if (dist < 0.75f && m.cool <= 0) { health -= 1.1f; hitFlash = 0.35f; m.cool = 1.0f; beep(2); }
                } else {
                    float a = noise(seed + m.id, (int)(m.x*5), (int)(m.z*5)) * 6.28318f;
                    m.x += Math.cos(a) * 0.35f * dt; m.z += Math.sin(a) * 0.35f * dt;
                }
                if (solid(blockAt(floor(m.x), floor(m.z)))) { m.x -= m.vx * dt; m.z -= m.vz * dt; }
                m.cool -= dt;
            }
            if (health <= 0) { health = 20; hunger = 20; px = 0.5f; pz = 0.5f; mobs.clear(); beep(2); }
        }

        void spawnMob(boolean hostile) {
            float a = noise(seed, mobs.size()+11, floor(px)+floor(pz)) * 6.28318f;
            float d = hostile ? 11f : 8f;
            Mob m = new Mob(); m.id = mobs.size() + 1; m.hostile = hostile;
            m.x = px + (float)Math.cos(a) * d; m.z = pz + (float)Math.sin(a) * d;
            if (!solid(blockAt(floor(m.x), floor(m.z)))) mobs.add(m);
        }

        void tryMove(float dx, float dz) {
            if (!solid(blockAt(floor(px + dx), floor(pz)))) px += dx;
            if (!solid(blockAt(floor(px), floor(pz + dz)))) pz += dz;
        }

        void draw(Canvas c) {
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            if (screen == MENU) drawMenu(c, w, h);
            else if (screen == SETTINGS) drawSettings(c, w, h);
            else if (screen == PAUSE) { drawGame(c, w, h); drawPause(c, w, h); }
            else drawGame(c, w, h);
        }

        void drawMenu(Canvas c, int w, int h) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(16, 31, 48)); c.drawRect(0,0,w,h,p);
            text.setTextSize(sp(40)); text.setColor(Color.WHITE); c.drawText("Voxel Forge", w/2f, h*0.26f, text);
            text.setTextSize(sp(16)); text.setColor(Color.rgb(200,225,210)); c.drawText("Crash-safe Android sandbox build", w/2f, h*0.33f, text);
            float bw = Math.min(w*0.45f, dp(290)), bh = dp(54), x = (w-bw)/2f;
            playBtn.set(x, h*0.43f, x+bw, h*0.43f+bh);
            settingsBtn.set(x, h*0.55f, x+bw, h*0.55f+bh);
            quitBtn.set(x, h*0.67f, x+bw, h*0.67f+bh);
            drawButton(c, playBtn, "Play World", Color.rgb(52,135,76));
            drawButton(c, settingsBtn, "Settings", Color.rgb(55,85,125));
            drawButton(c, quitBtn, "Quit", Color.rgb(90,65,65));
        }

        void drawSettings(Canvas c, int w, int h) {
            p.setColor(Color.rgb(18, 31, 45)); c.drawRect(0,0,w,h,p);
            text.setTextSize(sp(32)); text.setColor(Color.WHITE); c.drawText("Settings", w/2f, h*0.20f, text);
            text.setTextSize(sp(18));
            c.drawText("Tap left/right side to change", w/2f, h*0.30f, text);
            c.drawText("Sensitivity: " + Math.round(sensitivity*10000), w/2f, h*0.42f, text);
            c.drawText("Graphics quality: " + renderQuality, w/2f, h*0.52f, text);
            backBtn.set(w/2f-dp(135), h*0.68f, w/2f+dp(135), h*0.68f+dp(56));
            drawButton(c, backBtn, "Save and Back", Color.rgb(55,135,75));
        }

        void drawPause(Canvas c, int w, int h) {
            p.setColor(Color.argb(190,0,0,0)); c.drawRect(0,0,w,h,p);
            text.setTextSize(sp(34)); text.setColor(Color.WHITE); c.drawText("Paused", w/2f, h*0.28f, text);
            playBtn.set(w/2f-dp(130), h*0.42f, w/2f+dp(130), h*0.42f+dp(54));
            settingsBtn.set(w/2f-dp(130), h*0.55f, w/2f+dp(130), h*0.55f+dp(54));
            quitBtn.set(w/2f-dp(130), h*0.68f, w/2f+dp(130), h*0.68f+dp(54));
            drawButton(c, playBtn, "Resume", Color.rgb(50,135,75));
            drawButton(c, settingsBtn, "Settings", Color.rgb(55,85,125));
            drawButton(c, quitBtn, "Main Menu", Color.rgb(90,65,65));
        }

        void drawGame(Canvas c, int w, int h) {
            float l = light();
            p.setColor(mix(Color.rgb(25,35,68), Color.rgb(105,178,235), l)); c.drawRect(0,0,w,h/2f,p);
            p.setColor(mix(Color.rgb(25,28,32), Color.rgb(85,115,78), l)); c.drawRect(0,h/2f,w,h,p);
            drawRaycastWorld(c, w, h, l);
            drawMobs(c, w, h, l);
            drawHud(c, w, h);
            if (hitFlash > 0) { p.setColor(Color.argb((int)(100*hitFlash/0.35f),255,0,0)); c.drawRect(0,0,w,h,p); }
        }

        void drawRaycastWorld(Canvas c, int w, int h, float l) {
            int rays = Math.max(64, Math.min(160, w / (renderQuality == 1 ? 8 : 5)));
            float fov = (float)Math.toRadians(70);
            for (int i=0;i<rays;i++) {
                float t = (i / (float)(rays-1) - 0.5f);
                float a = yaw + t * fov;
                Ray r = castRayAngle(a, 18f);
                if (!r.hit) continue;
                float dist = Math.max(0.2f, r.dist * (float)Math.cos(t * fov));
                float wallH = Math.min(h*1.4f, h / dist * 0.92f);
                float x0 = i * w / (float)rays;
                float x1 = (i+1) * w / (float)rays + 1;
                int base = colorFor(r.block);
                float shade = Math.max(0.18f, l * (1.0f - dist/26f));
                p.setColor(shadeColor(base, shade));
                c.drawRect(x0, h/2f - wallH/2f - jump*18f, x1, h/2f + wallH/2f - jump*18f, p);
            }
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(Color.argb(70,0,0,0));
            c.drawLine(w/2f-dp(10), h/2f, w/2f+dp(10), h/2f, p); c.drawLine(w/2f, h/2f-dp(10), w/2f, h/2f+dp(10), p);
            p.setStyle(Paint.Style.FILL);
            Ray target = castRay(7f);
            if (target.hit) {
                text.setTextSize(sp(14)); text.setColor(Color.WHITE); c.drawText(nameFor(target.block), w/2f, h/2f - dp(24), text);
                if (breakHeld) { p.setColor(Color.argb(160,255,230,80)); c.drawCircle(w/2f, h/2f, dp(14) + breakTimer*dp(18), p); }
            }
        }

        void drawMobs(Canvas c, int w, int h, float l) {
            for (Mob m : mobs) {
                float dx = m.x - px, dz = m.z - pz;
                float dist = (float)Math.sqrt(dx*dx + dz*dz);
                if (dist < 0.2f || dist > 16f) continue;
                float ang = (float)Math.atan2(dx, dz) - yaw;
                while (ang > Math.PI) ang -= Math.PI*2; while (ang < -Math.PI) ang += Math.PI*2;
                float fov = (float)Math.toRadians(70);
                if (Math.abs(ang) > fov/2f) continue;
                float sx = w/2f + (ang/(fov/2f))*w/2f;
                float size = Math.min(dp(120), h / dist * 0.35f);
                p.setColor(m.hostile ? shadeColor(Color.rgb(185,68,75), l) : shadeColor(Color.rgb(190,150,95), l));
                c.drawRoundRect(sx-size/2, h/2f-size*0.75f, sx+size/2, h/2f+size*0.55f, dp(5), dp(5), p);
            }
        }

        void drawHud(Canvas c, int w, int h) {
            // joystick
            joyCx = dp(92); joyCy = h - dp(86);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(3)); p.setColor(Color.argb(150,255,255,255)); c.drawCircle(joyCx, joyCy, dp(54), p);
            p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(160,255,255,255)); c.drawCircle(joyCx + moveX*dp(38), joyCy + moveY*dp(38), dp(23), p);
            // action buttons
            float s = dp(62); pauseBtn.set(w-dp(75), dp(14), w-dp(16), dp(62));
            breakBtn.set(w-dp(225), h-dp(92), w-dp(225)+s, h-dp(30));
            placeBtn.set(w-dp(145), h-dp(92), w-dp(145)+s, h-dp(30));
            jumpBtn.set(w-dp(83), h-dp(166), w-dp(21), h-dp(104));
            craftBtn.set(w-dp(83), h-dp(92), w-dp(21), h-dp(30));
            drawButton(c, pauseBtn, "II", Color.rgb(45,60,75));
            drawButton(c, breakBtn, "Break", Color.rgb(130,70,55));
            drawButton(c, placeBtn, "Place", Color.rgb(60,110,70));
            drawButton(c, jumpBtn, "Jump", Color.rgb(65,100,150));
            drawButton(c, craftBtn, "Craft", Color.rgb(100,90,55));
            // bars
            drawBar(c, dp(18), dp(16), dp(180), dp(16), health/20f, Color.rgb(205,50,60), "HP");
            drawBar(c, dp(18), dp(38), dp(180), dp(16), hunger/20f, Color.rgb(230,165,45), "Food");
            text.setTextSize(sp(13)); text.setColor(Color.WHITE); text.setTextAlign(Paint.Align.LEFT);
            c.drawText((light()<0.35f?"Night":"Day") + "  Seed " + seed, dp(18), dp(70), text);
            text.setTextAlign(Paint.Align.CENTER);
            // hotbar
            float cell = dp(42), start = w/2f - cell*hotbar.length/2f;
            for (int i=0;i<hotbar.length;i++) {
                float x = start + i*cell;
                p.setStyle(Paint.Style.FILL); p.setColor(i==selected?Color.argb(230,255,255,255):Color.argb(150,20,20,20));
                c.drawRoundRect(x, h-dp(54), x+cell-dp(4), h-dp(12), dp(6), dp(6), p);
                p.setColor(colorFor(hotbar[i])); c.drawRect(x+dp(8), h-dp(45), x+cell-dp(12), h-dp(23), p);
                text.setTextSize(sp(10)); text.setColor(Color.WHITE); c.drawText(""+(i+1), x+cell/2f-dp(2), h-dp(16), text);
            }
        }

        void drawButton(Canvas c, RectF r, String label, int color) {
            p.setStyle(Paint.Style.FILL); p.setColor(color); c.drawRoundRect(r, dp(10), dp(10), p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); p.setColor(Color.argb(130,255,255,255)); c.drawRoundRect(r, dp(10), dp(10), p);
            p.setStyle(Paint.Style.FILL); text.setTextAlign(Paint.Align.CENTER); text.setColor(Color.WHITE); text.setTextSize(sp(15));
            c.drawText(label, r.centerX(), r.centerY() + dp(5), text);
        }

        void drawBar(Canvas c, float x, float y, float w, float h, float pct, int color, String label) {
            p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(160,0,0,0)); c.drawRoundRect(x,y,x+w,y+h,dp(4),dp(4),p);
            p.setColor(color); c.drawRoundRect(x,y,x+w*Math.max(0, Math.min(1, pct)),y+h,dp(4),dp(4),p);
            text.setTextAlign(Paint.Align.LEFT); text.setTextSize(sp(10)); text.setColor(Color.WHITE); c.drawText(label, x+w+dp(8), y+h-dp(3), text); text.setTextAlign(Paint.Align.CENTER);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            int action = e.getActionMasked(), idx = e.getActionIndex(), id = e.getPointerId(idx);
            float x = e.getX(idx), y = e.getY(idx);
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) touchDown(id, x, y);
            else if (action == MotionEvent.ACTION_MOVE) {
                for (int i=0;i<e.getPointerCount();i++) touchMove(e.getPointerId(i), e.getX(i), e.getY(i));
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) touchUp(id, x, y);
            return true;
        }

        void touchDown(int id, float x, float y) {
            int w=getWidth(), h=getHeight();
            if (screen == MENU) {
                if (playBtn.contains(x,y)) { screen = GAME; beep(3); }
                else if (settingsBtn.contains(x,y)) { screen = SETTINGS; beep(3); }
                else if (quitBtn.contains(x,y)) { ((Activity)getContext()).finish(); }
                return;
            }
            if (screen == SETTINGS) {
                if (backBtn.contains(x,y)) { save(); screen = MENU; beep(3); }
                else if (x < w/2f) { sensitivity = Math.max(0.003f, sensitivity - 0.001f); renderQuality = Math.max(1, renderQuality - 1); }
                else { sensitivity = Math.min(0.015f, sensitivity + 0.001f); renderQuality = Math.min(3, renderQuality + 1); }
                return;
            }
            if (screen == PAUSE) {
                if (playBtn.contains(x,y)) { screen = GAME; beep(3); }
                else if (settingsBtn.contains(x,y)) { screen = SETTINGS; beep(3); }
                else if (quitBtn.contains(x,y)) { save(); screen = MENU; beep(3); }
                return;
            }
            if (pauseBtn.contains(x,y)) { screen = PAUSE; save(); beep(3); return; }
            if (breakBtn.contains(x,y)) { breakHeld = true; return; }
            if (placeBtn.contains(x,y)) { placeBlock(); return; }
            if (jumpBtn.contains(x,y)) { jumpHeld = true; return; }
            if (craftBtn.contains(x,y)) { cycleHotbar(); return; }
            float cell = dp(42), start = w/2f - cell*hotbar.length/2f;
            if (y > h-dp(62) && x >= start && x <= start + cell*hotbar.length) {
                selected = Math.max(0, Math.min(hotbar.length-1, (int)((x-start)/cell))); beep(3); return;
            }
            if (x < w*0.36f) { leftPointer = id; joyX = x; joyY = y; updateMove(x,y); }
            else { rightPointer = id; lastLookX = x; }
        }

        void touchMove(int id, float x, float y) {
            if (screen != GAME) return;
            if (id == leftPointer) updateMove(x,y);
            if (id == rightPointer) { yaw += (x - lastLookX) * sensitivity; lastLookX = x; }
        }

        void touchUp(int id, float x, float y) {
            if (id == leftPointer) { leftPointer = -1; moveX = moveY = 0; }
            if (id == rightPointer) rightPointer = -1;
            if (breakBtn.contains(x,y)) breakHeld = false;
        }

        void updateMove(float x, float y) {
            moveX = clamp((x - joyCx) / dp(54), -1, 1);
            moveY = clamp((y - joyCy) / dp(54), -1, 1);
        }

        void cycleHotbar() { selected = (selected + 1) % hotbar.length; beep(3); }

        void placeBlock() {
            Ray r = castRay(5.5f);
            if (r.hit && inv[selected] > 0) {
                int x = r.prevX, z = r.prevZ;
                if (!solid(blockAt(x,z)) && !(floor(px)==x && floor(pz)==z)) {
                    setBlock(x, z, hotbar[selected]);
                    beep(4);
                }
            }
        }

        Ray castRay(float maxDist) { return castRayAngle(yaw, maxDist); }
        Ray castRayAngle(float a, float maxDist) {
            Ray r = new Ray();
            float sx=(float)Math.sin(a), cz=(float)Math.cos(a);
            int lastX=floor(px), lastZ=floor(pz);
            for (float d=0.05f; d<=maxDist; d+=0.045f) {
                int x=floor(px + sx*d), z=floor(pz + cz*d);
                byte b=blockAt(x,z);
                if (solid(b)) { r.hit=true; r.bx=x; r.bz=z; r.prevX=lastX; r.prevZ=lastZ; r.block=b; r.dist=d; return r; }
                lastX=x; lastZ=z;
            }
            r.dist=maxDist; return r;
        }

        byte blockAt(int x, int z) {
            Byte e = edits.get(key(x,z)); if (e != null) return e;
            float river = noise(seed+7, x/2, z/2);
            if (river < 0.10f && Math.abs(x+z)%5 < 2) return WATER;
            float beach = noise(seed+8, x, z);
            if (river < 0.16f) return SAND;
            float trees = noise(seed+22, x/3, z/3);
            if (trees > 0.88f && mod(x,3)==1 && mod(z,3)==1) return WOOD;
            float leaves = noise(seed+23, x/2, z/2);
            if (leaves > 0.93f) return LEAVES;
            float rock = noise(seed+33, x, z);
            if (rock > 0.94f) return STONE;
            if (rock < 0.035f) return ORE;
            return AIR;
        }

        void setBlock(int x, int z, byte b) { edits.put(key(x,z), b); }
        boolean solid(byte b) { return b != AIR && b != WATER && b != SAND; }

        float light() { return Math.max(0.18f, Math.min(1f, 0.25f + (float)Math.sin(day * Math.PI*2) * 0.82f)); }
        int colorFor(byte b) {
            switch (b) {
                case GRASS: return Color.rgb(80,170,80); case DIRT: return Color.rgb(120,80,45); case STONE: return Color.rgb(130,130,135);
                case SAND: return Color.rgb(215,195,125); case WATER: return Color.rgb(50,120,210); case WOOD: return Color.rgb(125,80,38);
                case LEAVES: return Color.rgb(60,145,70); case ORE: return Color.rgb(80,160,180); case TORCH: return Color.rgb(240,185,70);
                default: return Color.rgb(80,170,80);
            }
        }
        String nameFor(byte b) {
            switch (b) { case GRASS:return "Grass"; case DIRT:return "Dirt"; case STONE:return "Stone"; case SAND:return "Sand"; case WATER:return "Water"; case WOOD:return "Wood"; case LEAVES:return "Leaves"; case ORE:return "Ore"; case TORCH:return "Torch"; default:return "Block"; }
        }

        int mix(int a, int b, float t) {
            t = Math.max(0, Math.min(1, t));
            return Color.rgb((int)(Color.red(a)*(1-t)+Color.red(b)*t), (int)(Color.green(a)*(1-t)+Color.green(b)*t), (int)(Color.blue(a)*(1-t)+Color.blue(b)*t));
        }
        int shadeColor(int c, float s) { s=Math.max(0,Math.min(1,s)); return Color.rgb((int)(Color.red(c)*s), (int)(Color.green(c)*s), (int)(Color.blue(c)*s)); }

        float noise(int seed, int x, int z) { int n = x*374761393 + z*668265263 + seed*1442695041; n=(n^(n>>13))*1274126177; n^=n>>16; return (n & 0x7fffffff) / (float)0x7fffffff; }
        long key(int x, int z) { return (((long)x) << 32) ^ (z & 0xffffffffL); }
        int unpackX(long k) { return (int)(k >> 32); }
        int unpackZ(long k) { return (int)k; }
        int floor(float v) { return v >= 0 ? (int)v : (int)v - 1; }
        int mod(int a, int b) { int m=a%b; return m<0?m+b:m; }
        float clamp(float v, float a, float b) { return Math.max(a, Math.min(b, v)); }
        int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
        float sp(float v) { return v * getResources().getDisplayMetrics().scaledDensity; }
        void beep(int type) { if (tone != null) try { tone.startTone(type==1?ToneGenerator.TONE_PROP_BEEP:type==2?ToneGenerator.TONE_PROP_NACK:ToneGenerator.TONE_PROP_ACK, 55); } catch(Throwable ignored){} }

        static class Ray { boolean hit=false; int bx,bz,prevX,prevZ; byte block; float dist; }
        static class Mob { int id; boolean hostile; float x,z,vx,vz,cool; }
    }
}
