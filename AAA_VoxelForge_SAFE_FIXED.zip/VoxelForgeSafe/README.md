# Voxel Forge Safe Build

Crash-safe Android version built with plain Java Canvas rendering. It is designed to open reliably on Android phones, with mobile controls, procedural world, block breaking/placing, hotbar, mobs, day/night, and saving.
