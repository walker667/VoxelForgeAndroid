package com.example.voxelforge;

public class Player {
    public float x = 0f;
    public float y = 45f;
    public float z = 0f;
    public float yaw = 0f;
    public float pitch = -10f;
    public float vx = 0f;
    public float vy = 0f;
    public float vz = 0f;
    public boolean onGround = false;
    public float health = 20f;
    public float hunger = 20f;
    public int toolLevel = 0;
    public int[] inventory = new int[] {999, 999, 999, 999, 999, 999, 999, 999};
    public byte[] hotbar = new byte[] {Block.GRASS, Block.DIRT, Block.STONE, Block.SAND, Block.WOOD, Block.LEAVES, Block.TORCH, Block.WATER};

    public float eyeY() {
        return y + 1.58f;
    }
}
