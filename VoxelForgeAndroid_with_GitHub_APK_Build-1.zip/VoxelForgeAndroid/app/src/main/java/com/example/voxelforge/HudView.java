package com.example.voxelforge;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;

public class HudView extends View {
    private final InputState input;
    private final VoxelRenderer renderer;
    private final GameSettings settings;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int joystickPointer = -1;
    private int lookPointer = -1;
    private float joyStartX, joyStartY, joyX, joyY;
    private final float[] lastX = new float[12];
    private final float[] lastY = new float[12];
    private final RectF jump = new RectF();
    private final RectF brk = new RectF();
    private final RectF place = new RectF();
    private final RectF craft = new RectF();
    private final RectF pause = new RectF();
    private final RectF save = new RectF();
    private final Vibrator vibrator;

    public HudView(Context context, InputState input, VoxelRenderer renderer, GameSettings settings) {
        super(context);
        this.input = input;
        this.renderer = renderer;
        this.settings = settings;
        this.vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        setFocusable(true);
        text.setColor(Color.WHITE);
        text.setTextSize(dp(13));
        text.setShadowLayer(4, 1, 1, Color.BLACK);
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        int w = getWidth();
        int h = getHeight();
        updateRects(w, h);
        drawBars(c, w, h);
        drawHotbar(c, w, h);
        drawControls(c);
        drawCrosshair(c, w, h);
        drawStatus(c, w, h);
        invalidate();
    }

    private void updateRects(int w, int h) {
        float s = dp(62);
        jump.set(w - dp(92), h - dp(162), w - dp(30), h - dp(100));
        brk.set(w - dp(164), h - dp(93), w - dp(102), h - dp(31));
        place.set(w - dp(92), h - dp(93), w - dp(30), h - dp(31));
        craft.set(w - dp(236), h - dp(93), w - dp(174), h - dp(31));
        pause.set(w - dp(74), dp(16), w - dp(16), dp(58));
        save.set(w - dp(140), dp(16), w - dp(82), dp(58));
    }

    private void drawBars(Canvas c, int w, int h) {
        float x = dp(18), y = dp(16), bw = dp(180), bh = dp(15);
        Player player = renderer.getPlayerSnapshot();
        drawBar(c, x, y, bw, bh, player.health / 20f, Color.rgb(210, 50, 52), "Health");
        drawBar(c, x, y + dp(22), bw, bh, player.hunger / 20f, Color.rgb(228, 157, 45), "Hunger");
    }

    private void drawBar(Canvas c, float x, float y, float w, float h, float v, int color, String label) {
        p.setColor(Color.argb(160, 0, 0, 0));
        c.drawRoundRect(new RectF(x, y, x + w, y + h), dp(7), dp(7), p);
        p.setColor(color);
        c.drawRoundRect(new RectF(x, y, x + Math.max(dp(4), w * Math.max(0, Math.min(1, v))), y + h), dp(7), dp(7), p);
        c.drawText(label, x + dp(6), y + h - dp(3), text);
    }

    private void drawHotbar(Canvas c, int w, int h) {
        Player player = renderer.getPlayerSnapshot();
        int slots = player.hotbar.length;
        float size = dp(46);
        float total = slots * size;
        float x0 = w / 2f - total / 2f;
        float y0 = h - dp(58);
        for (int i = 0; i < slots; i++) {
            float x = x0 + i * size;
            p.setStyle(Paint.Style.FILL);
            p.setColor(i == input.selectedSlot ? Color.argb(210, 250, 240, 150) : Color.argb(135, 25, 25, 25));
            c.drawRoundRect(new RectF(x + dp(2), y0, x + size - dp(2), y0 + size - dp(4)), dp(8), dp(8), p);
            p.setColor(blockColor(player.hotbar[i]));
            c.drawRect(x + dp(13), y0 + dp(10), x + dp(33), y0 + dp(30), p);
            text.setTextSize(dp(10));
            c.drawText(Block.name(player.hotbar[i]).substring(0, Math.min(4, Block.name(player.hotbar[i]).length())), x + dp(7), y0 + dp(42), text);
        }
        text.setTextSize(dp(13));
    }

    private void drawControls(Canvas c) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(82, 255, 255, 255));
        float baseX = joystickPointer >= 0 ? joyStartX : dp(94);
        float baseY = joystickPointer >= 0 ? joyStartY : getHeight() - dp(96);
        c.drawCircle(baseX, baseY, dp(58), p);
        p.setColor(Color.argb(135, 255, 255, 255));
        c.drawCircle(joystickPointer >= 0 ? joyX : baseX, joystickPointer >= 0 ? joyY : baseY, dp(25), p);
        drawButton(c, jump, "Jump");
        drawButton(c, brk, "Break");
        drawButton(c, place, "Place");
        drawButton(c, craft, "Craft");
        drawButton(c, pause, "II");
        drawButton(c, save, "Save");
    }

    private void drawButton(Canvas c, RectF r, String label) {
        p.setColor(Color.argb(130, 20, 30, 42));
        c.drawRoundRect(r, dp(14), dp(14), p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(2));
        p.setColor(Color.argb(160, 255, 255, 255));
        c.drawRoundRect(r, dp(14), dp(14), p);
        p.setStyle(Paint.Style.FILL);
        text.setTextSize(dp(label.length() > 4 ? 11 : 14));
        text.setTextAlign(Paint.Align.CENTER);
        c.drawText(label, r.centerX(), r.centerY() + dp(5), text);
        text.setTextAlign(Paint.Align.LEFT);
        text.setTextSize(dp(13));
    }

    private void drawCrosshair(Canvas c, int w, int h) {
        p.setColor(Color.argb(210, 255, 255, 255));
        p.setStrokeWidth(dp(2));
        c.drawLine(w / 2f - dp(9), h / 2f, w / 2f + dp(9), h / 2f, p);
        c.drawLine(w / 2f, h / 2f - dp(9), w / 2f, h / 2f + dp(9), p);
    }

    private void drawStatus(Canvas c, int w, int h) {
        text.setTextSize(dp(13));
        Player player = renderer.getPlayerSnapshot();
        String mode = player.toolLevel == 0 ? "Hand" : player.toolLevel == 1 ? "Wood tool" : "Stone tool";
        c.drawText("Tool: " + mode + "  Day: " + renderer.getDayLabel(), dp(18), h - dp(10), text);
    }

    private int blockColor(byte b) {
        switch (b) {
            case Block.GRASS: return Color.rgb(70, 165, 65);
            case Block.DIRT: return Color.rgb(120, 76, 42);
            case Block.STONE: return Color.rgb(116, 116, 116);
            case Block.SAND: return Color.rgb(214, 195, 116);
            case Block.WOOD: return Color.rgb(118, 78, 38);
            case Block.LEAVES: return Color.rgb(40, 120, 55);
            case Block.WATER: return Color.rgb(52, 132, 210);
            case Block.TORCH: return Color.rgb(248, 202, 65);
            case Block.ORE: return Color.rgb(78, 132, 150);
            default: return Color.WHITE;
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        int index = e.getActionIndex();
        int pointerId = e.getPointerId(index);
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            float x = e.getX(index), y = e.getY(index);
            lastX[pointerId % lastX.length] = x;
            lastY[pointerId % lastY.length] = y;
            if (pause.contains(x, y)) { input.pausePressed = true; return true; }
            if (save.contains(x, y)) { input.savePressed = true; vibrate(); return true; }
            if (jump.contains(x, y)) { input.jumpHeld = true; vibrate(); return true; }
            if (brk.contains(x, y)) { input.breakingHeld = true; vibrate(); return true; }
            if (place.contains(x, y)) { input.placingHeld = true; vibrate(); return true; }
            if (craft.contains(x, y)) { input.craftPressed = true; vibrate(); return true; }
            int hot = hitHotbar(x, y);
            if (hot >= 0) { input.selectedSlot = hot; vibrate(); return true; }
            if (x < getWidth() * 0.42f && y > getHeight() * 0.38f && joystickPointer == -1) {
                joystickPointer = pointerId;
                joyStartX = x; joyStartY = y; joyX = x; joyY = y;
                updateJoystick(x, y);
            } else if (lookPointer == -1) {
                lookPointer = pointerId;
            }
        } else if (action == MotionEvent.ACTION_MOVE) {
            for (int i = 0; i < e.getPointerCount(); i++) {
                int id = e.getPointerId(i);
                float x = e.getX(i), y = e.getY(i);
                int slot = id % lastX.length;
                if (id == joystickPointer) updateJoystick(x, y);
                else if (id == lookPointer) input.addLook(x - lastX[slot], y - lastY[slot]);
                lastX[slot] = x;
                lastY[slot] = y;
            }
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) {
            if (pointerId == joystickPointer) {
                joystickPointer = -1;
                input.moveX = 0f;
                input.moveY = 0f;
            }
            if (pointerId == lookPointer) lookPointer = -1;
            float x = e.getX(index), y = e.getY(index);
            if (jump.contains(x, y)) input.jumpHeld = false;
            if (brk.contains(x, y)) input.breakingHeld = false;
            if (place.contains(x, y)) input.placingHeld = false;
            if (action == MotionEvent.ACTION_CANCEL || e.getPointerCount() <= 1) {
                input.jumpHeld = false;
                input.breakingHeld = false;
                input.placingHeld = false;
            }
        }
        return true;
    }

    private void updateJoystick(float x, float y) {
        float dx = x - joyStartX;
        float dy = y - joyStartY;
        float r = dp(56);
        float len = (float)Math.sqrt(dx * dx + dy * dy);
        if (len > r) { dx = dx / len * r; dy = dy / len * r; }
        joyX = joyStartX + dx;
        joyY = joyStartY + dy;
        input.moveX = dx / r;
        input.moveY = -dy / r;
    }

    private int hitHotbar(float x, float y) {
        Player player = renderer.getPlayerSnapshot();
        int slots = player.hotbar.length;
        float size = dp(46);
        float total = slots * size;
        float x0 = getWidth() / 2f - total / 2f;
        float y0 = getHeight() - dp(58);
        if (y < y0 || y > y0 + size) return -1;
        int i = (int)((x - x0) / size);
        return i >= 0 && i < slots ? i : -1;
    }

    private void vibrate() {
        try { if (vibrator != null) vibrator.vibrate(18); } catch (Exception ignored) {}
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
