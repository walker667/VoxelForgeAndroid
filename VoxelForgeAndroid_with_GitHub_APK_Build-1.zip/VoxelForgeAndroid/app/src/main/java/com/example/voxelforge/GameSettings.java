package com.example.voxelforge;

import android.content.Context;
import android.content.SharedPreferences;

public class GameSettings {
    public float sensitivity = 0.18f;
    public int renderDistance = 3;
    public float volume = 0.75f;
    public int quality = 1; // 0 low, 1 normal, 2 high

    public void load(Context context) {
        SharedPreferences p = context.getSharedPreferences("settings", Context.MODE_PRIVATE);
        sensitivity = p.getFloat("sensitivity", 0.18f);
        renderDistance = p.getInt("renderDistance", 3);
        volume = p.getFloat("volume", 0.75f);
        quality = p.getInt("quality", 1);
    }

    public void save(Context context) {
        context.getSharedPreferences("settings", Context.MODE_PRIVATE).edit()
                .putFloat("sensitivity", sensitivity)
                .putInt("renderDistance", renderDistance)
                .putFloat("volume", volume)
                .putInt("quality", quality)
                .apply();
    }
}
