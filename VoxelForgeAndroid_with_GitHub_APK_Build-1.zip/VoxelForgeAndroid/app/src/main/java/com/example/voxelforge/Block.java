package com.example.voxelforge;

public final class Block {
    private Block() {}

    public static final byte AIR = 0;
    public static final byte GRASS = 1;
    public static final byte DIRT = 2;
    public static final byte STONE = 3;
    public static final byte SAND = 4;
    public static final byte WOOD = 5;
    public static final byte LEAVES = 6;
    public static final byte WATER = 7;
    public static final byte ORE = 8;
    public static final byte TORCH = 9;

    public static boolean isSolid(byte b) {
        return b != AIR && b != WATER && b != TORCH;
    }

    public static boolean isTransparent(byte b) {
        return b == AIR || b == WATER || b == LEAVES || b == TORCH;
    }

    public static boolean isRenderable(byte b) {
        return b != AIR;
    }

    public static String name(byte b) {
        switch (b) {
            case GRASS: return "Grass";
            case DIRT: return "Dirt";
            case STONE: return "Stone";
            case SAND: return "Sand";
            case WOOD: return "Wood";
            case LEAVES: return "Leaves";
            case WATER: return "Water";
            case ORE: return "Ore";
            case TORCH: return "Torch";
            default: return "Air";
        }
    }

    public static int topTile(byte b) {
        switch (b) {
            case GRASS: return 0;
            case DIRT: return 2;
            case STONE: return 3;
            case SAND: return 4;
            case WOOD: return 6;
            case LEAVES: return 7;
            case WATER: return 8;
            case ORE: return 9;
            case TORCH: return 10;
            default: return 3;
        }
    }

    public static int sideTile(byte b) {
        switch (b) {
            case GRASS: return 1;
            case DIRT: return 2;
            case STONE: return 3;
            case SAND: return 4;
            case WOOD: return 5;
            case LEAVES: return 7;
            case WATER: return 8;
            case ORE: return 9;
            case TORCH: return 10;
            default: return 3;
        }
    }

    public static float breakTime(byte b, int toolLevel) {
        float base;
        switch (b) {
            case GRASS:
            case DIRT:
            case SAND: base = 0.35f; break;
            case WOOD:
            case LEAVES: base = 0.55f; break;
            case STONE: base = 1.15f; break;
            case ORE: base = 1.8f; break;
            default: base = 0.25f;
        }
        if (toolLevel == 1) base *= 0.72f;
        if (toolLevel >= 2) base *= 0.48f;
        return base;
    }
}
