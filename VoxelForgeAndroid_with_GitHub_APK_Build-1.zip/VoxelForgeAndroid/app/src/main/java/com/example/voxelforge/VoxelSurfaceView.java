package com.example.voxelforge;

import android.content.Context;
import android.opengl.GLSurfaceView;

public class VoxelSurfaceView extends GLSurfaceView {
    public VoxelSurfaceView(Context context, VoxelRenderer renderer) {
        super(context);
        setEGLContextClientVersion(2);
        setPreserveEGLContextOnPause(true);
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }
}
