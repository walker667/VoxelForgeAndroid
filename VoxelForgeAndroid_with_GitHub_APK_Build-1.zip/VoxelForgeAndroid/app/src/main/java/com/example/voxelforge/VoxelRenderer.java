package com.example.voxelforge;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.opengl.Matrix;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class VoxelRenderer implements GLSurfaceView.Renderer {
    private final Context context;
    private final InputState input;
    private final GameSettings settings;
    private final Runnable pauseCallback;
    private final SaveManager save;
    private final Player player = new Player();
    private final List<Entity> entities = new ArrayList<>();
    private final List<Particle> particles = new ArrayList<>();
    private World world;
    private SoundPool soundPool;
    private int sBreak, sPlace, sStep, sHurt, sMob, sJump, sClick;

    private int program;
    private int colorProgram;
    private int textureId;
    private int aPos, aUv, aShade, uMvp, uDay;
    private int cPos, cMvp, cColor;
    private final float[] projection = new float[16];
    private final float[] view = new float[16];
    private final float[] mvp = new float[16];
    private int width, height;
    private long lastTime = 0;
    private float dayTime = 0.25f;
    private float footstepTimer = 0f;
    private float saveTimer = 0f;
    private float placeCooldown = 0f;
    private float mobSpawnTimer = 0f;
    private Target target = new Target();
    private int breakingX = Integer.MIN_VALUE, breakingY, breakingZ;
    private float breakProgress = 0f;

    public VoxelRenderer(Context context, InputState input, GameSettings settings, Runnable pauseCallback) {
        this.context = context.getApplicationContext();
        this.input = input;
        this.settings = settings;
        this.pauseCallback = pauseCallback;
        this.save = new SaveManager(context);
        this.world = new World(save.seed());
        save.load(player, world);
        this.dayTime = save.dayTime();
    }

    @Override public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glEnable(GLES20.GL_CULL_FACE);
        GLES20.glCullFace(GLES20.GL_BACK);
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
        program = buildProgram(VERTEX_SHADER, FRAGMENT_SHADER);
        colorProgram = buildProgram(COLOR_VERTEX_SHADER, COLOR_FRAGMENT_SHADER);
        aPos = GLES20.glGetAttribLocation(program, "aPosition");
        aUv = GLES20.glGetAttribLocation(program, "aTexCoord");
        aShade = GLES20.glGetAttribLocation(program, "aShade");
        uMvp = GLES20.glGetUniformLocation(program, "uMVP");
        uDay = GLES20.glGetUniformLocation(program, "uDayLight");
        cPos = GLES20.glGetAttribLocation(colorProgram, "aPosition");
        cMvp = GLES20.glGetUniformLocation(colorProgram, "uMVP");
        cColor = GLES20.glGetUniformLocation(colorProgram, "uColor");
        textureId = loadTexture("block_atlas.png");
        setupSounds();
    }

    private void setupSounds() {
        AudioAttributes attrs = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        soundPool = new SoundPool.Builder().setMaxStreams(8).setAudioAttributes(attrs).build();
        sBreak = soundPool.load(context, R.raw.block_break, 1);
        sPlace = soundPool.load(context, R.raw.block_place, 1);
        sStep = soundPool.load(context, R.raw.footstep, 1);
        sHurt = soundPool.load(context, R.raw.hurt, 1);
        sMob = soundPool.load(context, R.raw.mob, 1);
        sJump = soundPool.load(context, R.raw.jump, 1);
        sClick = soundPool.load(context, R.raw.click, 1);
    }

    @Override public void onSurfaceChanged(GL10 gl, int width, int height) {
        this.width = width;
        this.height = height;
        GLES20.glViewport(0, 0, width, height);
        Matrix.perspectiveM(projection, 0, 70f, width / (float)Math.max(1, height), 0.08f, 240f);
    }

    @Override public void onDrawFrame(GL10 gl) {
        long now = System.nanoTime();
        float dt = lastTime == 0 ? 0.016f : Math.min(0.05f, (now - lastTime) / 1_000_000_000f);
        lastTime = now;

        if (input.consumePausePressed()) {
            play(sClick, 1f);
            pauseCallback.run();
            return;
        }
        if (input.consumeSavePressed()) saveGame();

        update(dt);
        drawFrame();
    }

    private void update(float dt) {
        player.yaw += input.consumeLookDx() * settings.sensitivity;
        player.pitch -= input.consumeLookDy() * settings.sensitivity;
        if (player.pitch > 86) player.pitch = 86;
        if (player.pitch < -86) player.pitch = -86;

        dayTime += dt / 360f;
        if (dayTime > 1f) dayTime -= 1f;
        updatePlayer(dt);
        world.updateChunks(player.x, player.z, settings.renderDistance);
        target = raycast(6.5f);
        updateBreakingAndPlacing(dt);
        updateCrafting();
        updateEntities(dt);
        updateParticles(dt);
        saveTimer += dt;
        if (saveTimer > 20f) { saveGame(); saveTimer = 0f; }
    }

    private void updatePlayer(float dt) {
        float yawRad = (float)Math.toRadians(player.yaw);
        float forwardX = (float)Math.sin(yawRad);
        float forwardZ = -(float)Math.cos(yawRad);
        float rightX = (float)Math.cos(yawRad);
        float rightZ = (float)Math.sin(yawRad);
        float mx = input.moveX;
        float mz = input.moveY;
        float len = (float)Math.sqrt(mx * mx + mz * mz);
        if (len > 1f) { mx /= len; mz /= len; }
        float speed = player.hunger < 4 ? 3.0f : 4.6f;
        float wantX = (rightX * mx + forwardX * mz) * speed;
        float wantZ = (rightZ * mx + forwardZ * mz) * speed;
        player.vx = approach(player.vx, wantX, 22f * dt);
        player.vz = approach(player.vz, wantZ, 22f * dt);

        if (input.jumpHeld && player.onGround && player.hunger > 1f) {
            player.vy = 6.4f;
            player.onGround = false;
            player.hunger = Math.max(0f, player.hunger - 0.05f);
            play(sJump, 0.8f);
        }
        player.vy -= 18f * dt;
        if (player.vy < -28f) player.vy = -28f;

        moveAxis(player.vx * dt, 0, 0);
        moveAxis(0, player.vy * dt, 0);
        moveAxis(0, 0, player.vz * dt);

        boolean moving = Math.abs(player.vx) + Math.abs(player.vz) > 0.6f && player.onGround;
        if (moving) {
            player.hunger = Math.max(0f, player.hunger - dt * 0.014f);
            footstepTimer -= dt;
            if (footstepTimer <= 0f) { play(sStep, 0.35f); footstepTimer = 0.42f; }
        }
        if (player.y < -10) {
            player.health -= 2f;
            player.x = 0;
            player.z = 0;
            player.y = world.heightAt(0, 0) + 4;
            player.vy = 0;
        }
        if (player.health <= 0f) {
            player.health = 20f;
            player.hunger = 20f;
            player.x = 0;
            player.z = 0;
            player.y = world.heightAt(0, 0) + 4;
            player.toolLevel = 0;
        }
    }

    private void moveAxis(float dx, float dy, float dz) {
        if (dy != 0) {
            float oldVy = player.vy;
            if (!collides(player.x, player.y + dy, player.z)) {
                player.y += dy;
                player.onGround = false;
            } else {
                if (oldVy < -11f && dy < 0f) {
                    float dmg = (-oldVy - 10f) * 0.8f;
                    player.health -= dmg;
                    if (dmg > 1f) play(sHurt, 1f);
                }
                if (dy < 0) player.onGround = true;
                player.vy = 0;
            }
            return;
        }
        if (!collides(player.x + dx, player.y, player.z + dz)) {
            player.x += dx;
            player.z += dz;
        } else {
            if (dx != 0) player.vx = 0;
            if (dz != 0) player.vz = 0;
        }
    }

    private boolean collides(float x, float y, float z) {
        float r = 0.31f;
        float h = 1.76f;
        int minX = World.floor(x - r), maxX = World.floor(x + r);
        int minY = World.floor(y), maxY = World.floor(y + h);
        int minZ = World.floor(z - r), maxZ = World.floor(z + r);
        for (int yy = minY; yy <= maxY; yy++) for (int zz = minZ; zz <= maxZ; zz++) for (int xx = minX; xx <= maxX; xx++) {
            if (Block.isSolid(world.getBlock(xx, yy, zz))) return true;
        }
        return false;
    }

    private float approach(float cur, float target, float delta) {
        if (cur < target) return Math.min(target, cur + delta);
        return Math.max(target, cur - delta);
    }

    private void updateBreakingAndPlacing(float dt) {
        if (input.breakingHeld && target.hit) {
            byte b = world.getBlock(target.x, target.y, target.z);
            if (target.x != breakingX || target.y != breakingY || target.z != breakingZ) {
                breakingX = target.x; breakingY = target.y; breakingZ = target.z; breakProgress = 0f;
            }
            breakProgress += dt;
            if (breakProgress >= Block.breakTime(b, player.toolLevel)) {
                world.setBlock(target.x, target.y, target.z, Block.AIR);
                addBreakParticles(target.x + 0.5f, target.y + 0.5f, target.z + 0.5f, b);
                play(sBreak, 0.8f);
                giveInventory(b);
                breakProgress = 0f;
            }
        } else {
            breakProgress = 0f;
            breakingX = Integer.MIN_VALUE;
        }

        placeCooldown -= dt;
        if (input.placingHeld && target.hit && placeCooldown <= 0f) {
            byte block = player.hotbar[Math.max(0, Math.min(player.hotbar.length - 1, input.selectedSlot))];
            int px = target.prevX, py = target.prevY, pz = target.prevZ;
            if (world.getBlock(px, py, pz) == Block.AIR || world.getBlock(px, py, pz) == Block.WATER) {
                world.setBlock(px, py, pz, block);
                if (collides(player.x, player.y, player.z)) world.setBlock(px, py, pz, Block.AIR);
                else {
                    play(sPlace, 0.75f);
                    placeCooldown = 0.25f;
                }
            }
        }
    }

    private void giveInventory(byte b) {
        for (int i = 0; i < player.hotbar.length; i++) if (player.hotbar[i] == b) player.inventory[i] = Math.min(999, player.inventory[i] + 1);
    }

    private void updateCrafting() {
        if (!input.consumeCraftPressed()) return;
        play(sClick, 1f);
        if (player.toolLevel == 0) {
            player.toolLevel = 1;
        } else if (player.toolLevel == 1) {
            player.toolLevel = 2;
        } else {
            int torchSlot = 6;
            if (torchSlot < player.inventory.length) player.inventory[torchSlot] = Math.min(999, player.inventory[torchSlot] + 8);
        }
    }

    private void updateEntities(float dt) {
        boolean night = getDayLight() < 0.32f;
        mobSpawnTimer -= dt;
        if (mobSpawnTimer <= 0f) {
            if (night && countType(Entity.HOSTILE) < 5) spawnEntity(Entity.HOSTILE);
            if (!night && countType(Entity.PASSIVE) < 8) spawnEntity(Entity.PASSIVE);
            mobSpawnTimer = night ? 6f : 10f;
        }
        Iterator<Entity> it = entities.iterator();
        while (it.hasNext()) {
            Entity e = it.next();
            if (distSq(e.x, e.z, player.x, player.z) > 80 * 80) { it.remove(); continue; }
            e.damageCooldown -= dt;
            if (e.type == Entity.HOSTILE && night) {
                float dx = player.x - e.x, dz = player.z - e.z;
                float len = (float)Math.sqrt(dx * dx + dz * dz) + 0.0001f;
                e.vx = dx / len * 2.0f;
                e.vz = dz / len * 2.0f;
                if (len < 1.35f && e.damageCooldown <= 0f) {
                    player.health -= 1.5f;
                    player.hunger = Math.max(0, player.hunger - 0.2f);
                    e.damageCooldown = 1.2f;
                    play(sHurt, 1f);
                }
            } else {
                float wander = Noise.value2D(world.seed + e.hashCode(), e.x, e.z, 0.15f);
                e.vx = (float)Math.cos(wander * 6.28f) * 0.45f;
                e.vz = (float)Math.sin(wander * 6.28f) * 0.45f;
            }
            e.x += e.vx * dt;
            e.z += e.vz * dt;
            e.y = world.heightAt(World.floor(e.x), World.floor(e.z)) + 1.02f;
        }
    }

    private int countType(int type) {
        int n = 0; for (Entity e : entities) if (e.type == type) n++; return n;
    }

    private void spawnEntity(int type) {
        float angle = (float)(Noise.hash01(world.seed, World.floor(player.x), World.floor(player.z), entities.size()) * Math.PI * 2.0);
        float dist = type == Entity.HOSTILE ? 18f : 10f;
        float x = player.x + (float)Math.cos(angle) * dist;
        float z = player.z + (float)Math.sin(angle) * dist;
        float y = world.heightAt(World.floor(x), World.floor(z)) + 1.02f;
        entities.add(new Entity(type, x, y, z));
        if (type == Entity.HOSTILE) play(sMob, 0.45f);
    }

    private float distSq(float ax, float az, float bx, float bz) {
        float dx = ax - bx, dz = az - bz; return dx * dx + dz * dz;
    }

    private void updateParticles(float dt) {
        Iterator<Particle> it = particles.iterator();
        while (it.hasNext()) {
            Particle p = it.next();
            p.life -= dt;
            if (p.life <= 0) { it.remove(); continue; }
            p.vy -= 12f * dt;
            p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
        }
    }

    private void addBreakParticles(float x, float y, float z, byte block) {
        for (int i = 0; i < 16; i++) {
            Particle p = new Particle();
            float a = (float)(Noise.hash01(world.seed + i, World.floor(x * 10), World.floor(z * 10), i) * Math.PI * 2);
            float sp = 1f + Noise.hash01(world.seed, i, World.floor(x), World.floor(z)) * 2.2f;
            p.x = x; p.y = y; p.z = z;
            p.vx = (float)Math.cos(a) * sp;
            p.vz = (float)Math.sin(a) * sp;
            p.vy = 1.2f + Noise.hash01(world.seed, i, World.floor(y), World.floor(z)) * 2.0f;
            p.life = 0.5f + Noise.hash01(world.seed, i, 4, 2) * 0.4f;
            p.block = block;
            particles.add(p);
        }
    }

    private void drawFrame() {
        float light = getDayLight();
        float night = 1f - light;
        float skyR = 0.13f * night + 0.48f * light;
        float skyG = 0.16f * night + 0.72f * light;
        float skyB = 0.26f * night + 0.95f * light;
        GLES20.glClearColor(skyR, skyG, skyB, 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        updateCamera();

        for (Chunk c : world.visibleChunks()) {
            c.ensureMesh();
            c.uploadIfNeeded();
        }
        GLES20.glUseProgram(program);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId);
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0);
        GLES20.glUniform1f(uDay, light);
        for (Chunk c : world.visibleChunks()) c.draw(aPos, aUv, aShade);
        drawEntities(light);
        drawParticles(light);
        if (target.hit) drawHighlight();
    }

    private void updateCamera() {
        float[] dir = lookDirection();
        Matrix.setLookAtM(view, 0, player.x, player.eyeY(), player.z,
                player.x + dir[0], player.eyeY() + dir[1], player.z + dir[2],
                0f, 1f, 0f);
        Matrix.multiplyMM(mvp, 0, projection, 0, view, 0);
    }

    private float[] lookDirection() {
        float yaw = (float)Math.toRadians(player.yaw);
        float pitch = (float)Math.toRadians(player.pitch);
        float cp = (float)Math.cos(pitch);
        return new float[]{(float)Math.sin(yaw) * cp, (float)Math.sin(pitch), -(float)Math.cos(yaw) * cp};
    }

    private Target raycast(float reach) {
        Target t = new Target();
        float[] dir = lookDirection();
        float ox = player.x, oy = player.eyeY(), oz = player.z;
        int lastX = World.floor(ox), lastY = World.floor(oy), lastZ = World.floor(oz);
        for (float d = 0; d <= reach; d += 0.08f) {
            int bx = World.floor(ox + dir[0] * d);
            int by = World.floor(oy + dir[1] * d);
            int bz = World.floor(oz + dir[2] * d);
            byte b = world.getBlock(bx, by, bz);
            if (b != Block.AIR && b != Block.WATER) {
                t.hit = true; t.x = bx; t.y = by; t.z = bz; t.prevX = lastX; t.prevY = lastY; t.prevZ = lastZ;
                return t;
            }
            lastX = bx; lastY = by; lastZ = bz;
        }
        return t;
    }

    private void drawEntities(float light) {
        Chunk.MeshArray out = new Chunk.MeshArray(1024);
        for (Entity e : entities) {
            byte tex = e.type == Entity.HOSTILE ? Block.ORE : Block.WOOD;
            addEntityCube(out, e.x - 0.32f, e.y - 1.0f, e.z - 0.32f, 0.64f, 0.9f, 0.64f, tex, 0.95f);
            addEntityCube(out, e.x - 0.24f, e.y - 0.05f, e.z - 0.24f, 0.48f, 0.45f, 0.48f, tex, 1.0f);
        }
        if (out.size() == 0) return;
        drawClientMesh(out.data(), out.size() / 6, light);
    }

    private void drawParticles(float light) {
        Chunk.MeshArray out = new Chunk.MeshArray(1024);
        for (Particle p : particles) addEntityCube(out, p.x - 0.045f, p.y - 0.045f, p.z - 0.045f, 0.09f, 0.09f, 0.09f, p.block, 1f);
        if (out.size() == 0) return;
        drawClientMesh(out.data(), out.size() / 6, light);
    }

    private void drawClientMesh(float[] data, int count, float light) {
        FloatBuffer fb = ByteBuffer.allocateDirect(data.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        fb.put(data).position(0);
        GLES20.glUseProgram(program);
        GLES20.glUniformMatrix4fv(uMvp, 1, false, mvp, 0);
        GLES20.glUniform1f(uDay, light);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
        int stride = 6 * 4;
        fb.position(0);
        GLES20.glEnableVertexAttribArray(aPos);
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, stride, fb);
        fb.position(3);
        GLES20.glEnableVertexAttribArray(aUv);
        GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, stride, fb);
        fb.position(5);
        GLES20.glEnableVertexAttribArray(aShade);
        GLES20.glVertexAttribPointer(aShade, 1, GLES20.GL_FLOAT, false, stride, fb);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, count);
    }

    private void addEntityCube(Chunk.MeshArray out, float x, float y, float z, float w, float h, float d, byte b, float shade) {
        int tile = Block.sideTile(b);
        float[] uv = uv(tile);
        face(out, x+w,y,z, x+w,y+h,z, x+w,y+h,z+d, x+w,y,z+d, uv, shade * 0.82f);
        face(out, x,y,z+d, x,y+h,z+d, x,y+h,z, x,y,z, uv, shade * 0.70f);
        face(out, x,y+h,z, x,y+h,z+d, x+w,y+h,z+d, x+w,y+h,z, uv, shade);
        face(out, x,y,z+d, x,y,z, x+w,y,z, x+w,y,z+d, uv, shade * 0.54f);
        face(out, x+w,y,z+d, x+w,y+h,z+d, x,y+h,z+d, x,y,z+d, uv, shade * 0.76f);
        face(out, x,y,z, x,y+h,z, x+w,y+h,z, x+w,y,z, uv, shade * 0.66f);
    }

    private float[] uv(int tile) {
        float cols = 4f, rows = 3f, inset = 0.002f;
        int col = tile % 4, row = tile / 4;
        return new float[]{col / cols + inset, row / rows + inset, (col + 1) / cols - inset, (row + 1) / rows - inset};
    }

    private void face(Chunk.MeshArray out,
                      float ax,float ay,float az,float bx,float by,float bz,float cx,float cy,float cz,float dx,float dy,float dz,float[] uv,float shade) {
        float u0=uv[0], v0=uv[1], u1=uv[2], v1=uv[3];
        vv(out, ax,ay,az,u0,v1,shade); vv(out, bx,by,bz,u0,v0,shade); vv(out, cx,cy,cz,u1,v0,shade);
        vv(out, ax,ay,az,u0,v1,shade); vv(out, cx,cy,cz,u1,v0,shade); vv(out, dx,dy,dz,u1,v1,shade);
    }

    private void vv(Chunk.MeshArray out, float x, float y, float z, float u, float v, float shade) {
        out.add(x); out.add(y); out.add(z); out.add(u); out.add(v); out.add(shade);
    }

    private void drawHighlight() {
        float x = target.x - 0.002f, y = target.y - 0.002f, z = target.z - 0.002f, s = 1.004f;
        float[] lines = {
                x,y,z, x+s,y,z, x+s,y,z, x+s,y,z+s, x+s,y,z+s, x,y,z+s, x,y,z+s, x,y,z,
                x,y+s,z, x+s,y+s,z, x+s,y+s,z, x+s,y+s,z+s, x+s,y+s,z+s, x,y+s,z+s, x,y+s,z+s, x,y+s,z,
                x,y,z, x,y+s,z, x+s,y,z, x+s,y+s,z, x+s,y,z+s, x+s,y+s,z+s, x,y,z+s, x,y+s,z+s
        };
        FloatBuffer fb = ByteBuffer.allocateDirect(lines.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        fb.put(lines).position(0);
        GLES20.glUseProgram(colorProgram);
        GLES20.glUniformMatrix4fv(cMvp, 1, false, mvp, 0);
        float pulse = breakProgress > 0 ? Math.min(1f, breakProgress / Math.max(0.1f, Block.breakTime(world.getBlock(target.x, target.y, target.z), player.toolLevel))) : 0f;
        GLES20.glUniform4f(cColor, 1f, 1f - pulse * 0.35f, 0.2f, 0.92f);
        GLES20.glLineWidth(3f);
        GLES20.glEnableVertexAttribArray(cPos);
        GLES20.glVertexAttribPointer(cPos, 3, GLES20.GL_FLOAT, false, 0, fb);
        GLES20.glDrawArrays(GLES20.GL_LINES, 0, lines.length / 3);
    }

    private float getDayLight() {
        float sun = (float)Math.sin(dayTime * Math.PI * 2f);
        return Math.max(0.18f, Math.min(1f, 0.25f + sun * 0.82f));
    }

    public String getDayLabel() { return getDayLight() < 0.32f ? "Night" : "Day"; }

    public Player getPlayerSnapshot() {
        Player p = new Player();
        p.x = player.x; p.y = player.y; p.z = player.z; p.yaw = player.yaw; p.pitch = player.pitch;
        p.health = player.health; p.hunger = player.hunger; p.toolLevel = player.toolLevel;
        p.inventory = player.inventory.clone(); p.hotbar = player.hotbar.clone();
        return p;
    }

    public void saveGame() {
        if (world != null) save.save(player, world, dayTime);
    }

    private void play(int id, float mul) {
        if (soundPool != null && id != 0) soundPool.play(id, settings.volume * mul, settings.volume * mul, 1, 0, 1f);
    }

    private int buildProgram(String vertex, String fragment) {
        int vs = compileShader(GLES20.GL_VERTEX_SHADER, vertex);
        int fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fragment);
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, vs);
        GLES20.glAttachShader(p, fs);
        GLES20.glLinkProgram(p);
        int[] ok = new int[1];
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException(GLES20.glGetProgramInfoLog(p));
        return p;
    }

    private int compileShader(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        int[] ok = new int[1];
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException(GLES20.glGetShaderInfoLog(s));
        return s;
    }

    private int loadTexture(String assetName) {
        try {
            int[] ids = new int[1];
            GLES20.glGenTextures(1, ids, 0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0]);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
            InputStream is = context.getAssets().open(assetName);
            Bitmap bmp = BitmapFactory.decodeStream(is);
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0);
            bmp.recycle();
            return ids[0];
        } catch (Exception e) {
            throw new RuntimeException("Texture load failed: " + assetName, e);
        }
    }

    private static final String VERTEX_SHADER =
            "uniform mat4 uMVP;\n" +
            "uniform float uDayLight;\n" +
            "attribute vec3 aPosition;\n" +
            "attribute vec2 aTexCoord;\n" +
            "attribute float aShade;\n" +
            "varying vec2 vTexCoord;\n" +
            "varying float vLight;\n" +
            "void main(){\n" +
            "  gl_Position = uMVP * vec4(aPosition, 1.0);\n" +
            "  vTexCoord = aTexCoord;\n" +
            "  vLight = aShade * (0.20 + 0.80 * uDayLight);\n" +
            "}\n";

    private static final String FRAGMENT_SHADER =
            "precision mediump float;\n" +
            "uniform sampler2D uTexture;\n" +
            "varying vec2 vTexCoord;\n" +
            "varying float vLight;\n" +
            "void main(){\n" +
            "  vec4 tex = texture2D(uTexture, vTexCoord);\n" +
            "  if(tex.a < 0.08) discard;\n" +
            "  gl_FragColor = vec4(tex.rgb * vLight, tex.a);\n" +
            "}\n";

    private static final String COLOR_VERTEX_SHADER =
            "uniform mat4 uMVP; attribute vec3 aPosition; void main(){ gl_Position = uMVP * vec4(aPosition,1.0); }";
    private static final String COLOR_FRAGMENT_SHADER =
            "precision mediump float; uniform vec4 uColor; void main(){ gl_FragColor = uColor; }";

    private static class Target {
        boolean hit = false;
        int x, y, z;
        int prevX, prevY, prevZ;
    }

    private static class Particle {
        float x, y, z, vx, vy, vz, life;
        byte block;
    }
}
