package com.example.voxelforge;

import android.content.Context;
import android.content.SharedPreferences;

public class SaveManager {
    private final SharedPreferences prefs;

    public SaveManager(Context context) {
        prefs = context.getSharedPreferences("world_save", Context.MODE_PRIVATE);
    }

    public int seed() {
        if (!prefs.contains("seed")) prefs.edit().putInt("seed", (int)(System.currentTimeMillis() & 0x7fffffff)).apply();
        return prefs.getInt("seed", 12345);
    }

    public void save(Player p, World world, float dayTime) {
        StringBuilder inv = new StringBuilder();
        for (int i = 0; i < p.inventory.length; i++) {
            if (i > 0) inv.append(',');
            inv.append(p.inventory[i]);
        }
        prefs.edit()
                .putInt("seed", world.seed)
                .putFloat("px", p.x).putFloat("py", p.y).putFloat("pz", p.z)
                .putFloat("yaw", p.yaw).putFloat("pitch", p.pitch)
                .putFloat("health", p.health).putFloat("hunger", p.hunger)
                .putInt("tool", p.toolLevel)
                .putString("inv", inv.toString())
                .putFloat("day", dayTime)
                .putString("edits", world.saveEdits())
                .apply();
    }

    public void load(Player p, World world) {
        if (!prefs.contains("px")) {
            p.x = 0;
            p.z = 0;
            p.y = world.heightAt(0, 0) + 4;
            return;
        }
        p.x = prefs.getFloat("px", 0f);
        p.y = prefs.getFloat("py", world.heightAt(0, 0) + 4);
        p.z = prefs.getFloat("pz", 0f);
        p.yaw = prefs.getFloat("yaw", 0f);
        p.pitch = prefs.getFloat("pitch", -10f);
        p.health = prefs.getFloat("health", 20f);
        p.hunger = prefs.getFloat("hunger", 20f);
        p.toolLevel = prefs.getInt("tool", 0);
        String inv = prefs.getString("inv", "");
        if (inv != null && !inv.isEmpty()) {
            String[] parts = inv.split(",");
            for (int i = 0; i < parts.length && i < p.inventory.length; i++) {
                try { p.inventory[i] = Integer.parseInt(parts[i]); } catch (Exception ignored) {}
            }
        }
        world.loadEdits(prefs.getString("edits", ""));
    }

    public float dayTime() { return prefs.getFloat("day", 0.25f); }
}
