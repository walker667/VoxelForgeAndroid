package com.example.voxelforge;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Arrays;

public class Chunk {
    public final int cx;
    public final int cz;
    private final World world;
    private final byte[] blocks = new byte[World.CHUNK_SIZE * World.HEIGHT * World.CHUNK_SIZE];
    private boolean dirty = true;
    private float[] mesh;
    private int vertexCount = 0;
    private int vbo = 0;
    private boolean glDirty = false;

    public Chunk(World world, int cx, int cz) {
        this.world = world;
        this.cx = cx;
        this.cz = cz;
        generate();
    }

    private int idx(int x, int y, int z) {
        return (y * World.CHUNK_SIZE + z) * World.CHUNK_SIZE + x;
    }

    public byte getLocal(int x, int y, int z) {
        if (x < 0 || x >= World.CHUNK_SIZE || z < 0 || z >= World.CHUNK_SIZE || y < 0 || y >= World.HEIGHT) return Block.AIR;
        return blocks[idx(x, y, z)];
    }

    public void setLocal(int x, int y, int z, byte b) {
        if (x < 0 || x >= World.CHUNK_SIZE || z < 0 || z >= World.CHUNK_SIZE || y < 0 || y >= World.HEIGHT) return;
        blocks[idx(x, y, z)] = b;
        markDirty();
    }

    public void markDirty() { dirty = true; }

    private void generate() {
        int baseX = cx * World.CHUNK_SIZE;
        int baseZ = cz * World.CHUNK_SIZE;
        for (int z = 0; z < World.CHUNK_SIZE; z++) {
            for (int x = 0; x < World.CHUNK_SIZE; x++) {
                int wx = baseX + x;
                int wz = baseZ + z;
                for (int y = 0; y < World.HEIGHT; y++) {
                    byte b = world.generatedBlock(wx, y, wz);
                    byte tree = world.treeBlock(wx, y, wz);
                    if (tree != Block.AIR && b == Block.AIR) b = tree;
                    blocks[idx(x, y, z)] = b;
                }
            }
        }
        for (java.util.Map.Entry<Long, Byte> e : world.getEdits().entrySet()) {
            int[] xyz = World.unpackEdit(e.getKey());
            int lx = xyz[0] - baseX;
            int lz = xyz[2] - baseZ;
            if (lx >= 0 && lx < World.CHUNK_SIZE && lz >= 0 && lz < World.CHUNK_SIZE && xyz[1] >= 0 && xyz[1] < World.HEIGHT) {
                blocks[idx(lx, xyz[1], lz)] = e.getValue();
            }
        }
        dirty = true;
    }

    public void ensureMesh() {
        if (!dirty) return;
        MeshArray out = new MeshArray(8192);
        int baseX = cx * World.CHUNK_SIZE;
        int baseZ = cz * World.CHUNK_SIZE;
        for (int z = 0; z < World.CHUNK_SIZE; z++) {
            for (int y = 0; y < World.HEIGHT; y++) {
                for (int x = 0; x < World.CHUNK_SIZE; x++) {
                    byte b = blocks[idx(x, y, z)];
                    if (!Block.isRenderable(b)) continue;
                    int wx = baseX + x;
                    int wz = baseZ + z;
                    addVisibleFaces(out, wx, y, wz, b);
                }
            }
        }
        mesh = out.data();
        vertexCount = out.size() / 6;
        dirty = false;
        glDirty = true;
    }

    private boolean shouldDrawFace(byte current, byte neighbor) {
        if (current == Block.WATER) return neighbor != Block.WATER;
        if (current == Block.LEAVES) return neighbor == Block.AIR || neighbor == Block.WATER;
        if (current == Block.TORCH) return neighbor != Block.TORCH;
        return Block.isTransparent(neighbor);
    }

    private void addVisibleFaces(MeshArray out, int wx, int y, int wz, byte b) {
        if (shouldDrawFace(b, world.getBlock(wx + 1, y, wz))) addFace(out, wx, y, wz, b, 0);
        if (shouldDrawFace(b, world.getBlock(wx - 1, y, wz))) addFace(out, wx, y, wz, b, 1);
        if (shouldDrawFace(b, world.getBlock(wx, y + 1, wz))) addFace(out, wx, y, wz, b, 2);
        if (shouldDrawFace(b, world.getBlock(wx, y - 1, wz))) addFace(out, wx, y, wz, b, 3);
        if (shouldDrawFace(b, world.getBlock(wx, y, wz + 1))) addFace(out, wx, y, wz, b, 4);
        if (shouldDrawFace(b, world.getBlock(wx, y, wz - 1))) addFace(out, wx, y, wz, b, 5);
    }

    private void addFace(MeshArray out, float x, float y, float z, byte b, int face) {
        int tile = (face == 2) ? Block.topTile(b) : Block.sideTile(b);
        if (face == 3 && b == Block.GRASS) tile = Block.topTile(Block.DIRT);
        float shade;
        switch (face) {
            case 2: shade = 1.00f; break;
            case 3: shade = 0.54f; break;
            case 0: shade = 0.82f; break;
            case 1: shade = 0.70f; break;
            case 4: shade = 0.76f; break;
            default: shade = 0.66f; break;
        }
        float s = 1f;
        if (b == Block.TORCH) {
            s = 0.25f;
            x += 0.375f;
            z += 0.375f;
        }
        float x0 = x, x1 = x + s, y0 = y, y1 = y + (b == Block.TORCH ? 0.78f : 1f), z0 = z, z1 = z + s;
        float[] uv = uv(tile);
        float u0 = uv[0], v0 = uv[1], u1 = uv[2], v1 = uv[3];
        switch (face) {
            case 0: // +x
                quad(out, x1,y0,z0, u0,v1, x1,y1,z0, u0,v0, x1,y1,z1, u1,v0, x1,y0,z1, u1,v1, shade); break;
            case 1: // -x
                quad(out, x0,y0,z1, u0,v1, x0,y1,z1, u0,v0, x0,y1,z0, u1,v0, x0,y0,z0, u1,v1, shade); break;
            case 2: // top
                quad(out, x0,y1,z0, u0,v1, x0,y1,z1, u0,v0, x1,y1,z1, u1,v0, x1,y1,z0, u1,v1, shade); break;
            case 3: // bottom
                quad(out, x0,y0,z1, u0,v1, x0,y0,z0, u0,v0, x1,y0,z0, u1,v0, x1,y0,z1, u1,v1, shade); break;
            case 4: // +z
                quad(out, x1,y0,z1, u0,v1, x1,y1,z1, u0,v0, x0,y1,z1, u1,v0, x0,y0,z1, u1,v1, shade); break;
            case 5: // -z
                quad(out, x0,y0,z0, u0,v1, x0,y1,z0, u0,v0, x1,y1,z0, u1,v0, x1,y0,z0, u1,v1, shade); break;
        }
    }

    private float[] uv(int tile) {
        float cols = 4f, rows = 3f;
        int col = tile % 4;
        int row = tile / 4;
        float inset = 0.002f;
        float u0 = col / cols + inset;
        float v0 = row / rows + inset;
        float u1 = (col + 1f) / cols - inset;
        float v1 = (row + 1f) / rows - inset;
        return new float[]{u0, v0, u1, v1};
    }

    private void quad(MeshArray out,
                      float ax,float ay,float az,float au,float av,
                      float bx,float by,float bz,float bu,float bv,
                      float cx,float cy,float cz,float cu,float cv,
                      float dx,float dy,float dz,float du,float dv,
                      float shade) {
        v(out, ax,ay,az,au,av,shade); v(out, bx,by,bz,bu,bv,shade); v(out, cx,cy,cz,cu,cv,shade);
        v(out, ax,ay,az,au,av,shade); v(out, cx,cy,cz,cu,cv,shade); v(out, dx,dy,dz,du,dv,shade);
    }

    private void v(MeshArray out, float x, float y, float z, float u, float v, float shade) {
        out.add(x); out.add(y); out.add(z); out.add(u); out.add(v); out.add(shade);
    }

    public void uploadIfNeeded() {
        if (!glDirty || mesh == null) return;
        if (vbo == 0) {
            int[] ids = new int[1];
            GLES20.glGenBuffers(1, ids, 0);
            vbo = ids[0];
        }
        FloatBuffer fb = ByteBuffer.allocateDirect(mesh.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        fb.put(mesh).position(0);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo);
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, mesh.length * 4, fb, GLES20.GL_STATIC_DRAW);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
        mesh = null;
        glDirty = false;
    }

    public void draw(int posLoc, int uvLoc, int shadeLoc) {
        if (vbo == 0 || vertexCount == 0) return;
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo);
        int stride = 6 * 4;
        GLES20.glEnableVertexAttribArray(posLoc);
        GLES20.glVertexAttribPointer(posLoc, 3, GLES20.GL_FLOAT, false, stride, 0);
        GLES20.glEnableVertexAttribArray(uvLoc);
        GLES20.glVertexAttribPointer(uvLoc, 2, GLES20.GL_FLOAT, false, stride, 3 * 4);
        GLES20.glEnableVertexAttribArray(shadeLoc);
        GLES20.glVertexAttribPointer(shadeLoc, 1, GLES20.GL_FLOAT, false, stride, 5 * 4);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertexCount);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
    }

    public void releaseGl() {
        if (vbo != 0) {
            int[] ids = {vbo};
            GLES20.glDeleteBuffers(1, ids, 0);
            vbo = 0;
        }
    }

    static class MeshArray {
        private float[] a;
        private int n = 0;
        MeshArray(int cap) { a = new float[cap]; }
        void add(float v) { if (n >= a.length) a = Arrays.copyOf(a, a.length * 2); a[n++] = v; }
        int size() { return n; }
        float[] data() { return Arrays.copyOf(a, n); }
    }
}
