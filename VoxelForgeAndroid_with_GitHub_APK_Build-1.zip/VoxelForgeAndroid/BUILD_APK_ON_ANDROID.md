# Build the APK using only your Android phone

You cannot install the project ZIP directly. Android needs an `.apk` file.

The easiest no-computer method is GitHub Actions. It builds the APK online for you.

## Steps

1. Make a free GitHub account if you do not have one.
2. Open GitHub in Chrome on your Android.
3. Create a new repository named `VoxelForgeAndroid`.
4. Upload all files from this project ZIP into that repository.
   - Make sure the repository contains `app/`, `build.gradle`, `settings.gradle`, and `.github/workflows/build-apk.yml`.
5. Go to the repository's **Actions** tab.
6. Open **Build Android APK**.
7. Tap **Run workflow**.
8. When it finishes, open the completed workflow run.
9. Download the artifact named `VoxelForge-debug-apk`.
10. Unzip it on your phone.
11. Tap `app-debug.apk` to install.
12. If Android blocks it, allow installs from Chrome or Files, then install again.

## If the workflow fails

Open the failed workflow and copy the red error text. Send it back here and I can fix the project files.
