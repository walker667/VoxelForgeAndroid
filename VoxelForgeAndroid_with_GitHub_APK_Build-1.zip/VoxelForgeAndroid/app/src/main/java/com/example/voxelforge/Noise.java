package com.example.voxelforge;

public final class Noise {
    private Noise() {}

    public static float value2D(int seed, float x, float z, float frequency) {
        float fx = x * frequency;
        float fz = z * frequency;
        int x0 = fastFloor(fx);
        int z0 = fastFloor(fz);
        float tx = smooth(fx - x0);
        float tz = smooth(fz - z0);
        float a = hash01(seed, x0, z0, 0);
        float b = hash01(seed, x0 + 1, z0, 0);
        float c = hash01(seed, x0, z0 + 1, 0);
        float d = hash01(seed, x0 + 1, z0 + 1, 0);
        float ab = lerp(a, b, tx);
        float cd = lerp(c, d, tx);
        return lerp(ab, cd, tz) * 2f - 1f;
    }

    public static float value3D(int seed, float x, float y, float z, float frequency) {
        float fx = x * frequency, fy = y * frequency, fz = z * frequency;
        int x0 = fastFloor(fx), y0 = fastFloor(fy), z0 = fastFloor(fz);
        float tx = smooth(fx - x0), ty = smooth(fy - y0), tz = smooth(fz - z0);
        float c000 = hash01(seed, x0, z0, y0);
        float c100 = hash01(seed, x0 + 1, z0, y0);
        float c010 = hash01(seed, x0, z0, y0 + 1);
        float c110 = hash01(seed, x0 + 1, z0, y0 + 1);
        float c001 = hash01(seed, x0, z0 + 1, y0);
        float c101 = hash01(seed, x0 + 1, z0 + 1, y0);
        float c011 = hash01(seed, x0, z0 + 1, y0 + 1);
        float c111 = hash01(seed, x0 + 1, z0 + 1, y0 + 1);
        float x00 = lerp(c000, c100, tx);
        float x10 = lerp(c010, c110, tx);
        float x01 = lerp(c001, c101, tx);
        float x11 = lerp(c011, c111, tx);
        float y0v = lerp(x00, x10, ty);
        float y1v = lerp(x01, x11, ty);
        return lerp(y0v, y1v, tz) * 2f - 1f;
    }

    public static float fractal2D(int seed, float x, float z) {
        float amp = 1f, freq = 0.018f, sum = 0f, total = 0f;
        for (int i = 0; i < 4; i++) {
            sum += value2D(seed + i * 93, x, z, freq) * amp;
            total += amp;
            amp *= 0.5f;
            freq *= 2.1f;
        }
        return sum / total;
    }

    public static float hash01(int seed, int x, int z, int y) {
        int n = x * 374761393 + z * 668265263 + y * 2147483647 + seed * 1274126177;
        n = (n ^ (n >> 13)) * 1274126177;
        n = n ^ (n >> 16);
        return (n & 0x7fffffff) / (float)0x7fffffff;
    }

    private static int fastFloor(float f) { return f >= 0 ? (int)f : (int)f - 1; }
    private static float smooth(float t) { return t * t * (3f - 2f * t); }
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
}
