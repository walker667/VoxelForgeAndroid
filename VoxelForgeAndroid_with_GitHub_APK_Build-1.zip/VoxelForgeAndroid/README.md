# Voxel Forge Android

Voxel Forge is an original Minecraft-inspired Android voxel sandbox. It uses no Mojang/Minecraft names, textures, audio, logos, or assets. The project is a pure Android + Java + OpenGL ES app, so you can open it in Android Studio and export a real APK.

## What is included

- First-person 3D voxel world
- Mobile touch controls: joystick, drag look, jump, break, place, craft, save, pause
- Procedural chunk terrain with grass, dirt, stone, sand, water, wood, leaves, ore, trees, caves, beaches, hills, plains, and forests
- Chunk loading/unloading with face-culling mesh generation
- Original generated pixel texture atlas
- Original generated WAV sounds
- Raycast block targeting and block highlight
- Break progress, place system, creative hotbar, basic crafting/tool progression
- Health, hunger, fall damage, hostile night mobs, passive day animals
- Day/night cycle with changing sky and light
- Main menu, loading screen, pause menu, settings screen
- Save/load for seed, player position, inventory/tool, time of day, and edited blocks

## Folder structure

```text
VoxelForgeAndroid/
  settings.gradle
  build.gradle
  README.md
  app/
    build.gradle
    src/main/
      AndroidManifest.xml
      assets/
        block_atlas.png
      java/com/example/voxelforge/
        Block.java
        Chunk.java
        Entity.java
        GameSettings.java
        HudView.java
        InputState.java
        MainActivity.java
        Noise.java
        Player.java
        SaveManager.java
        VoxelRenderer.java
        VoxelSurfaceView.java
        World.java
      res/
        drawable/ic_launcher_foreground.xml
        raw/ambient.wav
        raw/block_break.wav
        raw/block_place.wav
        raw/click.wav
        raw/footstep.wav
        raw/hurt.wav
        raw/jump.wav
        raw/mob.wav
        values/strings.xml
        values/styles.xml
```

## Build requirements

- Android Studio with JDK 17
- Android SDK Platform 35
- Android SDK Build Tools 35.x
- Gradle 8.13 or newer
- Android Gradle Plugin 8.12.2 is declared in the root `build.gradle`

## Build the APK in Android Studio

1. Download and unzip this project.
2. Open Android Studio.
3. Choose **Open** and select the `VoxelForgeAndroid` folder.
4. Let Android Studio sync Gradle. If it asks to install SDK Platform 35 or Build Tools 35, accept.
5. Connect your Android phone with USB debugging enabled, or use an emulator.
6. Press **Run** to test.
7. To export an APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
8. Android Studio will show a link to the generated APK, usually:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Install on Android phone

### USB install from Android Studio

1. On your phone, enable **Developer options**.
2. Turn on **USB debugging**.
3. Plug your phone into the computer.
4. In Android Studio, choose your device and press **Run**.

### Manual APK install

1. Copy `app-debug.apk` to your phone.
2. Open it from Files/Downloads.
3. Allow installation from that app when Android asks.
4. Install and open **Voxel Forge**.

## Controls

- Left joystick: move
- Right side drag: look around
- Jump: jump
- Break: hold to mine the targeted block
- Place: place the selected hotbar block on the targeted face
- Hotbar: tap a slot to select a block
- Craft: upgrades from hand to wood tool, then stone tool, then adds torches
- Save: saves world instantly
- Pause: opens pause menu

## Performance tips

- Use render distance 2 on slower phones.
- Use graphics quality 0 if the game stutters.
- Close background apps before testing.
- Debug builds are slower than release builds. A signed release build will usually run better.

## Debugging if it does not build

### `SDK location not found`

Open Android Studio and install the Android SDK from **Settings > Languages & Frameworks > Android SDK**.

### `compileSdk 35 is not installed`

Open **Tools > SDK Manager**, install **Android API 35**, then sync again.

### `Android Gradle plugin requires Java 17`

Use Android Studio's bundled JDK:

```text
File > Settings > Build, Execution, Deployment > Build Tools > Gradle > Gradle JDK > Embedded JDK
```

### APK does not install

- Uninstall any older version of Voxel Forge first.
- Make sure your phone allows installing unknown apps.
- Build a fresh debug APK.
- Check that your phone is Android 6.0/API 23 or newer.

### App opens then crashes

Open Android Studio **Logcat** and look for `com.example.voxelforge`. Common fixes:

- Lower render distance to 2.
- Make sure `block_atlas.png` exists in `app/src/main/assets/`.
- Make sure all `.wav` files exist in `app/src/main/res/raw/`.
- Try a physical device with OpenGL ES 2.0+ support.

## Upgrade ideas

This version is designed to build and run first. Good next upgrades:

- True greedy meshing instead of per-face meshing
- Better transparent water sorting
- Real inventory/crafting screen
- More mob AI and animations
- Lighting propagation from torches
- World save files instead of SharedPreferences for huge worlds
- Multiplayer LAN mode

## Build using only Android / no computer

I added a GitHub Actions workflow at:

```text
.github/workflows/build-apk.yml
```

This lets GitHub build the APK online. See:

```text
BUILD_APK_ON_ANDROID.md
```

